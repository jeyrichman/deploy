#!/bin/sh

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin

b_dir="/home/backup/conf/";

if [ `ls -1 $b_dir | wc -l` -eq 7 ];
then
        rm -rf $b_dir/`ls -1 $b_dir | head -1`;
fi

new_dir=`date '+%F_%T'`;
mkdir -p $b_dir/$new_dir;

if [ -e /usr/local/apache2/conf/ ]; then
    APACHE_DIR='/usr/local/apache2/conf/';
elif [ -e /etc/httpd/conf ]; then
    APACHE_DIR='/etc/httpd/conf';
fi
rsync -aHv ${APACHE_DIR} $b_dir/$new_dir/apache/

if [ -e /usr/local/nginx/conf/ ]; then
    rsync -aHv /usr/local/nginx/conf/ $b_dir/$new_dir/nginx/
fi

if [ -e /etc/tinydns/ ]; then
    rsync -aHv /etc/tinydns/ $b_dir/$new_dir/tinydns/
fi

if [ -e /etc/tinydns2/ ]; then
    rsync -aHv /etc/tinydns2/ $b_dir/$new_dir/tinydns2/
fi

if [ -e /etc/tinydns3/ ]; then
    rsync -aHv /etc/tinydns3/ $b_dir/$new_dir/tinydns3/
fi

if [ -e /etc/tinydns4/ ]; then
    rsync -aHv /etc/tinydns4/ $b_dir/$new_dir/tinydns4/
fi

if [ -e /etc/openvpn/ ]; then
	    rsync -aHv /etc/openvpn/ $b_dir/$new_dir/openvpn/
fi

if [ -e /etc/exim/ ]; then
	    rsync -aHv /etc/exim/ $b_dir/$new_dir/exim/
fi

package Module;

use Socket;
use Sys::Syslog qw(:DEFAULT setlogsock);
use strict;

our @ISA = qw(Exporter);
our @EXPORT = qw (
  %main_conf
  %email
  %action2email
  %sysctl_conf
  %temperature_conf
  %dyn_apache_conf
  %apache_logs_conf
  %run_ps_conf
  %mem_ps_conf
  %mysql_ps_conf
  @count_ps_conf
  @not_mon_fs_conf
  &load_conf
  &update_rrd_data
  &init
  &restart
  &mon_net_if
  &mon_alive
  &mon_disk_usage
  &mon_mbuf_clusters_usage
  &mon_sysctl_usage
  &mon_temperature
  &mon_raid_health
  &mon_hdd_overload
  &mon_swap_usage
  &mon_la
  &mon_zombie_count
  &mon_socket_overload
  &mon_apache_max_clients
  &mon_mysql
  &mon_ps
  &mon_cpu_overload
  &mon_kmem_usage
  &mon_apache_page
  &get_net_if_traffic
  &get_cpu_usage
  &get_la
  &get_ps_count
  &get_mysql_stats
  &get_temperature
  &get_disk_usage
  &get_mem_usage
  &get_ps_size
  &get_user_activity
  &get_hdd_stats
  &get_sysctl_usage
  &get_mbuf_clusters_usage
);
our $VERSION='0.0.1';

# config options
our %main_conf = (
  'mail' => 'mail', # /usr/bin/mail
  'temperature_prog' => 'mbmon -c1 -T4',
  'start_time' => 45,
  'mon_net_if_period' => 3600,  # seconds
  'mon_alive_period' => 3600,   # seconds
  'disk_space_max_usage' => 95, # %
  'disk_space_usage_increment' => 1, # %
  'disk_space_min_rest' => 100, # megabytes
  'disk_space_mon_min_rest' => 5120, # megabytes
  'disk_inodes_max_usage' => 70, # %
  'disk_inodes_usage_increment' => 10, # %
  'mbuf_clusters_max_usage' => 95, # %
  'mbuf_clusters_usage_increment' => 1, # %
  'sysctl_max_usage' => 95, # %
  'sysctl_usage_increment' => 1, # %
  'temperature_usage_increment' => 2,
  'mon_hdd_overload_period' => 3600, # seconds
  'hdd_max_overload' => 50, # %
  'mon_raid_health_period' => 86400, # seconds, 3600 * 24
  'swap_max_usage' => 300, # megabytes
  'swap_usage_increment' => 20, # megabytes
  'swap_in_out_usage' => 1, # megabytes
  'swap_in_out_increment' => 1, # megabytes
  'memory_min_usage' => 200, # megabytes
  'apache_max_memory_size' => 7, # megabytes
  'la_max' => 30,
  'la_increment' => 10,
  'zc_max' => 100, # zombie max count
  'zc_increment' => 50, # zombie count increment
  'so_max' => 95, # socket max overusage, % 
  'so_increment' => 2, # socket overusage increment, %
  'ps_load_max' => 80,
  'pc_max' => 2000,
  'cputime_max' => 300, # seconds
  'cpu_mul_renice' => 30, # %
  'cpu_mul_restart' => 30, # %
  'idle_min' => 10,
  'renice_value' => 10,
  'mon_cpu_overload_period' => 3600, # seconds
  'min_cpu_overload_idle' => 50,
  'max_cpu_overload_sys_interrupt' => 20,
  'kmem_usage' => 90, # %
  'kmem_usage_apache_restart' => 95, # %
  'kmem_usage_reboot' => 98, # %
  'kmem_increment' => 1, # %
  'mon_all' => 1,
  'mon_raid_health' => 1,
  'mon_hdd_overload' => 1,
  'mon_swap_usage' => 1,
  'mon_swap_active_usage' => 1,
  'mon_ps_zombie' => 1, 
  'mon_overload_ps' => 1, # грузящие процессы
  'mon_cpu_overload' => 0,
  'mon_run_ps' => 1,   # запущенные процессы
  'mon_ps_count' => 1,
  'mon_la' => 1, 
  'mon_zombie_count' => 1, 
  'mon_mysql' => 1, 
  'mon_kmem_usage' => 1, 
  'mon_socket_overload' => 1, # netstat -anL
  'mon_apache_maxclients' => 1,
  'mon_disk_usage' => 1,
  'mon_sysctl_usage' => 1,
  'mon_mbuf_clusters_usage' => 1,
  'mon_mbmon_temperature' => 0,
  'mon_sysctl_temperature' => 1,
  'mon_alive' => 0,
  'mon_net_if' => 1,
  'apache_conf_path' => '/usr/local/apache2/conf/vhost',
  'mon_apache_page' => 1,
  'mon_apache_page_period' => 300,  # seconds
  'mon_apache_page_nonempty' => 1,
);

our %email = (
  1 => 'notify@notify.king-support.com'
);

our %action2email = (
  'init' => $email{1},
  'net_if' => $email{1},
  'disk_usage' => $email{1},
  'mbuf' => $email{1},
  'sysctl' => $email{1},
  'temperature' => $email{1},
  'raid' => $email{1},
  'hdd_overload' => $email{1},
  'cpu_overload' => $email{1},
  'swap_usage' => $email{1},
  'la' => $email{1},
  'zombie_count' => $email{1},
  'socket_overload' => $email{1},
  'apache_max_clients' => $email{1},
  'mysql' => $email{1},
  'ps' => $email{1},
  'alive' => $email{1},
  'kmem_usage' => $email{1},
  'apache_page' => $email{1},
);

our %sysctl_conf = (
  'kern.openfiles' => 'kern.maxfiles',
  'kern.ipc.pipekva' => 'kern.ipc.maxpipekva',
  '80:1|kern.ipc.nsfbufsused' => 'kern.ipc.nsfbufs',
  'kern.ipc.numopensockets' => 'kern.ipc.maxsockets'
);

our @count_ps_conf = qw(
  /usr/sbin/cron 
  /usr/sbin/sshd 
  /usr/sbin/inetd 
  /usr/local/libexec/tnftpd
  /usr/sbin/syslogd 
  /usr/local/bin/mysqld_safe
  /usr/local/apache/bin/httpd
);

our %temperature_conf = (
  'box' => 70,
  'processor' => 70
);

our %dyn_apache_conf = (
  'root|/usr/local/apache2/bin/httpd' => '/usr/local/apache2/bin/apachectl stop; sleep 3|/usr/local/apache2/bin/apachectl start; sleep 3'
);

our %apache_logs_conf = (
  '/usr/local/apache2/bin/httpd' => '/home/logs/error_log'
);

our %run_ps_conf = (
  'root|/usr/sbin/cron' => '/etc/rc.d/cron start; sleep 3',
  'root|/usr/local/libexec/tnftpd' => '/etc/rc.d/ftpd start; sleep 3',
  'root|/usr/local/sbin/nginx' => '/usr/local/etc/rc.d/nginx restart; sleepd 3',
  'mysql|/usr/local/bin/mysqld_safe' => '/usr/local/etc/rc.d/mysql-server* start; sleep 3',
  'root|/usr/local/apache2/bin/httpd' => 'rm -f /usr/local/apache2/logs/httpd.pid; /usr/local/apache2/bin/apachectl start; sleep 3',
  'mailnull|/usr/local/sbin/exim' => '/usr/local/etc/rc.d/exim restart; sleep 3'
);

our %mem_ps_conf = (
  '/usr/local/libexec/mysqld' => '1:/usr/local/etc/rc.d/mysql-server* stop; sleep 3; /usr/local/etc/rc.d/mysql-server* start; sleep 3',
  '/usr/local/apache2/bin/httpd' => '2:restart_dyn_apaches'
);

our %mysql_ps_conf = (
  '/usr/local/libexec/mysqld|/tmp/mysql.sock' => '/usr/local/etc/rc.d/mysql-server* stop; sleep 3; /usr/local/etc/rc.d/mysql-server* start; sleep 3'
);

our @not_mon_fs_conf;

my %prev_values;

my %no_alarm;

my %load_ps;

my @mailservers = qw(
  162.244.33.240
  162.244.32.2
);

# procedures && functions
sub data_to_mb($) {
  my $data = shift;
  $data = int(1000 * $data / 1024) / 1000 if ($data =~ s/K$//i);
  $data =~ s/M$//i;
  return $data;
}

sub check_limit_usage($$$$) {
  my ($current, $key, $limit, $increment) = @_;
  if ($current >= $limit && !exists($prev_values{"$key"})) {
    $prev_values{"$key"} = $current;
    return 1;
  } elsif (exists($prev_values{"$key"}) && $current - $prev_values{"$key"} >= $increment) {
    $prev_values{"$key"} = $current;
    return 1;
  } elsif ($current < $limit && exists($prev_values{"$key"})) {
    delete($prev_values{"$key"});
  } 
  return 0;
}

sub load_conf($$) {
  my ($conf_file, $warn) = @_;
  eval {
    require $conf_file;
  };
  if ($@) {
    print "Loading $conf_file:\n$@" if ($warn);
    return 0;
  } else {
    return 1;
  }
}

sub get_rrd_data($$$) { # rrdres = 60 | 300 | 3600 | 43200 | 172800 only! 
  my ($rrd, $function, $rrdres) = @_;
  my @rrddata = `rrdtool fetch $rrd $function -r $rrdres -e @{[int(time()/$rrdres)*$rrdres]} -s e-$rrdres`;
  chomp(@rrddata);
  pop(@rrddata);
  my $names = shift(@rrddata);
  $names =~ s#^\s+##;
  $names =~ s#\s+$##;
  my $values = pop(@rrddata);
  $values =~ s#^.+:##;
  $values =~ s#^\s+##;
  $values =~ s#\s+$##;
  my %main_data;
  @main_data{split(/\s+/, $names)} = split(/\s+/, $values);
  return \%main_data;
}

sub update_rrd_data($@) {
  my $rrd = shift;
  my @values = @_;
  `rrdtool update $rrd N:@{[join(':', @values)]}`;
}

sub init($) {            
  my $email = shift;
  my $pid = (grep(m#^\s*(?!$$ )(\d+) /usr/bin/perl .+/mon.pl#, `ps xwwo pid,command`))[0];  
  if ($main_conf{'stop'}) {
    if ($pid) {
      $pid =~ s#^\s+##;
      kill(15, (split(m#\s+#, $pid))[0]);
      print STDERR "pid @{[(split(m#\s+#, $pid))[0]]} terminated...\n";
      $pid = 0;
    }
    exit unless ($main_conf{'daemon'});
  }
  exit if ($pid);
  if ($main_conf{'daemon'}) {
    chdir "/tmp";
    my $child_pid = fork();
    if (!defined $child_pid) { 
      &mail($email, 'SysMon :: Start', 'Monitor is not started');
      die("Fork: $!\n");
    }
    $SIG{'CHLD'} = 'IGNORE';
    exit(0) if ($child_pid);
    close STDIN;
    close STDOUT;
    close STDERR;
    open STDIN, "/dev/null";
    open STDOUT, "/dev/null";
    open STDERR, "/dev/null";
    &mail($email, 'SysMon :: Start', "Monitor started successfully\n") unless ($main_conf{'stop'});
  }
}

sub mail($$$) {
  sub sendSMTP($) {
    my $buffer = shift;
    send(SMTP, $buffer, 0);
    recv(SMTP, $buffer, 200, 0);
    $buffer = (split(/\s+/, $buffer))[0];
    return 0 if ($buffer =~ /^(4|5)/);
    return 1;
  }
  my ($email, $subject, $body) = @_;
  my ($check, $code);
  my @date = gmtime;
  $date[5] += 1900;
  $date[4]++;
  if (!$main_conf{'daemon'}) {
    print STDERR "$subject\n$body$date[5]-$date[4]-$date[3]+$date[2]:$date[1]:$date[0]\n";
  } else {
    foreach (@mailservers) {
      my ($mailhost, $proto, $port, $myhostname) = ($_, 6, 25, `hostname`);  # mailserver, tcp, smtp, my hostname
      chomp($myhostname);
      my $iaddr = inet_aton($mailhost) || next;  # could not resolve $mailhost
      my $paddr = sockaddr_in($port, $iaddr);
      socket(SMTP, AF_INET(), SOCK_STREAM(), $proto) || next; # could not connect to $mailhost
      connect(SMTP, $paddr) || next; # could not connect to $mailhost
      select(SMTP);
      $| = 1;
      select(STDOUT);
      my $inpBuf;
      recv(SMTP, $inpBuf, 200, 0);
      next if (!$inpBuf);
      next if (!sendSMTP("HELO mail.king-support.com\n"));
      next if (!sendSMTP("MAIL FROM: <root\@$myhostname>\n"));
      foreach (split /,/, $email) {
        next if (!length($_));
        $code = 1 if (sendSMTP("RCPT TO: <$_>\n"));
      }
      next if (!$code);
      next if (!sendSMTP("DATA\n"));
      send(SMTP, "From: <root\@$myhostname>\n", 0);
      foreach (split /,/, $email) {
        next if (!length($_));
        send(SMTP, "To: <$_>\n", 0);
      }
      send(SMTP, "Subject: $subject\n\n", 0);
      send(SMTP, "$body", 0);
      send(SMTP, "$date[5]-$date[4]-$date[3]+$date[2]:$date[1]:$date[0]\n", 0);
      next if (!sendSMTP("\r\n.\r\n"));
      next if (!sendSMTP("QUIT\n"));
      close(SMTP);
      $check = 1;
      last;
    }
    if (!$check) {
      foreach (split /,/, $email) {
        next if (!length($_));
        open MAIL, "|$main_conf{'mail'} -s '$subject' $_";
        print MAIL "$body$date[5]-$date[4]-$date[3]+$date[2]:$date[1]:$date[0]\n";
        close MAIL;
      }
    }
  }
  openlog 'sysmon', 'cons, pid', 'user';
  setlogsock "unix";
  syslog 'err', "$subject - $body";
  closelog();
}

sub restart($$) {
  my ($main_prog, $file, $first_file_mtime) = @_;
  my $file_mtime = (stat $file)[9];
  if ($file_mtime != $first_file_mtime) {
    openlog 'sysmon', 'cons, pid', 'user';
    syslog 'err', "Mtime of $file was changed. Reloading...";
    closelog();
    if (!exec("$main_prog -stop -daemon")) {
      openlog 'sysmon', 'cons, pid', 'user';
      syslog 'err', "%m";
      closelog();
      die;
    }
  }
}

sub restart_dyn_apaches() {
  my $status;
  foreach (keys(%dyn_apache_conf)) {
    my ($user, $process) = split(/\|/, $_, 2);
    my ($stop, $start) = split(/\|/, $dyn_apache_conf{$_}, 2);
    `$stop`;
    sleep(3);
    my $pid = (split(/\s+/, `ps -axwww -U '$user' | grep '$process' | grep -v grep`))[0];
    if (!$pid) {
      `$start`;
      if (!$?) {
        $status .= "$process: restarted;" 
      } else {
        $status .= "$process: could not restarted;";
      }
    } else {
      if (!kill(9, $pid)) {
        $status .= "$process: could not restarted;";
      } else {
        `$start`;
        if ($? == 0) {
          $status .= "$process: restarted;" 
        } else {
          $status .= "$process: could not restarted;";
        }
      }
    }
  }
  $status =~ s/\;$//;
  return $status; 
}

sub mon_net_if($$) {
  return unless ($main_conf{'mon_net_if'});
  my ($email, $mon_cycles) = @_;
  $mon_cycles *= 60;
  my $body = '';
  return unless ($main_conf{'mon_net_if_period'});
  return unless ($mon_cycles % $main_conf{'mon_net_if_period'} >= 0 && $mon_cycles % $main_conf{'mon_net_if_period'} < 1);
  my @net_ifs = sort(grep(!/(ppp|tap|tun|ng|lo|pfsync|pflog)\d+/, split(/\s+/, `ifconfig -u -l`)));
  foreach (@net_ifs) {
    my $net_if = $_;
    my $media = (grep(/media/i, `ifconfig $net_if`))[0];
    my $bw = $1 if ($media =~ /(\d+)/);
    if ($media =~ /half\-duplex/ && $bw != 1000) {
      `ifconfig '$net_if' media '$bw' BaseTX mediaopt full-duplex`;
      if ($?) {
        $body .= "Network interface $net_if is in $media now. Could not change\n";
      } else {
        $body .= "Network interface $net_if was in $media. Successfully changed\n";
      }
    }
  }
  &mail($email, 'SysMon :: Network Interface', $body) if (length($body));
}

sub mon_disk_usage($) {
  return unless ($main_conf{'mon_disk_usage'});
  my $email = shift;
  my $body = '';
  my @d_u_current = `df -ikt ufs,zfs`;
  shift(@d_u_current);
  foreach (@d_u_current) {
    chomp;
    my ($size, $avail, $capacity, $inodes, $mount_point) = (split(/\s+/, $_, 9))[1, 3, 4, 7, 8];
    next if ($mount_point eq '/.mysqlbackup');
    $capacity =~ s/\%$//;
    $inodes =~ s/\%$//;
    next if (grep(/^$mount_point$/, @not_mon_fs_conf));
    if ($avail / 1024 < $main_conf{'disk_space_mon_min_rest'}) {
      if ($avail / 1024 <= $main_conf{'disk_space_min_rest'}) {
        $body .= "$mount_point(free $avail, usage $capacity%)\n";
      } else {
        if (&check_limit_usage($capacity, "du_$mount_point", $main_conf{'disk_space_max_usage'}, $main_conf{'disk_space_usage_increment'})) {
          $body .= "$mount_point(free $avail, usage $capacity%)\n";
        }
      }
    }
    if (&check_limit_usage($inodes, "inodes_$mount_point", $main_conf{'disk_inodes_max_usage'}, $main_conf{'disk_inodes_usage_increment'})) {
      $body .= "$mount_point(inodes usage $inodes%)\n";
    }
  }
  &mail($email, 'SysMon :: Disk OverUsage', $body) if (length($body));
}

sub mon_mbuf_clusters_usage($$) {
  return unless ($main_conf{'mon_mbuf_clusters_usage'});
  my ($email, $os_release) = @_;
  my ($current, $max);
  my $body = '';
  my @data = `netstat -m`;
  if ($os_release < 5.0) {   # FreeBSD 4.x
    my $row = (grep(m#\d+/\d+/\d+\s+mbuf\s+clusters\s+in\s+use#, @data))[0];
    ($current, $max) = ($1, $2) if ($row =~ m#(\d+)/\d+/(\d+)\s+mbuf\s+clusters\s+in\s+use#);
  } elsif ($os_release >= 5.0 && $os_release < 5.3) {    # FreeBSD 5.x >= 5.0, < 5.3
    my $row1 = (grep(m#Total:\s+\d+/#, @data))[1];
    my $row2 = (grep(m#Maximum\s+possible:\s+\d+#, @data))[1];
    $current = $1 if ($row1 =~ /Total:\s+(\d+)\//);
    $max = $1 if ($row2 =~ /Maximum\s+possible:\s+(\d+)/);
  } elsif ($os_release  >= 5.3 && $os_release < 6.0 ) {    # FreeBSD 5.x >= 5.3, < 6.0
    my $row = (grep(m#\d+/\d+\s+mbuf\s+clusters\s+in\s+use#, @data))[0];
    ($current, $max) = ($1, $2) if ($row =~ m#(\d+)/(\d+)\s+mbuf\s+clusters\s+in\s+use#);
  } elsif ($os_release >= 6.0) {           # FreeBSD >= 6.0
    my $row = (grep(m#\d+/\d+/\d+/\d+\s+mbuf\s+clusters\s+in\s+use#, @data))[0];
    ($current, $max) = ($1, $2) if ($row =~ m#(\d+)/\d+/\d+/(\d+)\s+mbuf\s+clusters\s+in\s+use#);
  }
  return unless ($max);
  if (&check_limit_usage($current / $max * 100, "mbuf_clusters", $main_conf{'mbuf_clusters_max_usage'}, 
    $main_conf{'mbuf_clusters_usage_increment'})) 
  {
    $body .= "current / max =" . $current / $max * 100 . "%\n";
  }
  &mail($email, 'SysMon :: Mbuf OverUsage', $body) if (length($body));
}

sub mon_sysctl_usage($) {
  return unless ($main_conf{'mon_sysctl_usage'});
  my $email = shift;
  my $sysctl_usage;
  my $body = '';
  my %c_sysctl_conf;
  foreach (keys(%sysctl_conf)) {
    my $key = $_;
    $key =~ s#^.+\|##;
    $c_sysctl_conf{$key} = $sysctl_conf{$_};
  }
  my ($string1, $string2) = (join(' ', keys(%c_sysctl_conf)), join(' ', values(%c_sysctl_conf)));
  my (%sysctl_current, %sysctl_max);
  @sysctl_current{keys(%c_sysctl_conf)} = split(/\n/, `sysctl -n $string1 2>&1`);
  @sysctl_max{keys(%c_sysctl_conf)} = split(/\n/, `sysctl -n $string2 2>&1`);
  foreach(keys(%sysctl_conf)) {
    my ($usage_inc, $key);
    if ($_ =~ m#^.+\|#) {
      ($usage_inc, $key) = split(m#\|#, $_, 2);
    } else {
      $key = $_;
    }
    my $usage = defined($usage_inc) ? (split(m#:#, $usage_inc, 2))[0] : $main_conf{'sysctl_max_usage'};
    my $inc = defined($usage_inc) ? (split(m#:#, $usage_inc, 2))[1] : $main_conf{'sysctl_usage_increment'};
    my ($current, $max) = ($sysctl_current{$key}, $sysctl_max{$key}); 
    $sysctl_usage = ($current =~ /^sysctl:\s+unknown\s+oid/ || $max =~ /^sysctl:\s+unknown\s+oid/ || $max == 0) ? 0 : $current / $max * 100;
    if (&check_limit_usage($sysctl_usage, "$key", $usage, $inc)) {
      $body .= "$key / $c_sysctl_conf{$key} = " . $sysctl_usage . "%\n";
    }
  }
  &mail($email, 'SysMon :: Sysctl OverUsage', $body) if (length($body));
}

sub mon_temperature($$) {
  my ($email, $os_release) = @_;
  my $ncpu;
  my $body = '';
  if ($main_conf{'mon_mbmon_temperature'}) {
    my @temperature = split(/\n/, `$main_conf{'temperature_prog'} 2>/dev/null`, 2);
    if (!$?) {
      if (&check_limit_usage($temperature[0], "temperature_mbmon_processor", $temperature_conf{'processor'}, $main_conf{'temperature_usage_increment'})) {
        $body .= "processor [mbmon]: $temperature[0]\n";
      }
      if (&check_limit_usage($temperature[1], "temperature_mbmon_box", $temperature_conf{'box'}, $main_conf{'temperature_usage_increment'})) {
        $body .= "box [mbmon]: $temperature[1]\n";
      }
    }
  }
  if ($main_conf{'mon_sysctl_temperature'} && $os_release >= 7.0) {
    chomp($ncpu = `sysctl -n hw.ncpu`);
    for (my $i = 0; $i < $ncpu; $i++) {
      my $temperature;
      chomp($temperature = `sysctl -n dev.cpu.$i.temperature 2>/dev/null`);
      next unless ($temperature);
      if (&check_limit_usage($temperature, "temperature_sysctl_processor.$i", $temperature_conf{'processor'}, $main_conf{'temperature_usage_increment'})) {
        $body .= "processor $i [sysctl]: $temperature\n";
      }
    }
  }
  &mail($email, 'SysMon :: High Temperature', $body) if (length($body));
}

sub mon_raid_health($$) {
  my ($email, $mon_cycles) = @_;
  return unless ($main_conf{'mon_raid_health'});
  $mon_cycles *= 60;
  return unless ($main_conf{'mon_raid_health_period'});
  return unless ($mon_cycles % $main_conf{'mon_raid_health_period'} >= 0 && $mon_cycles % $main_conf{'mon_raid_health_period'} < 1);
  my ($twa, $done) = (0, 0);
  my ($count, $device);
  my ($body, $err) = ('', '');
  $twa = 1 if (grep(/^hw\.twa/, `sysctl -a 2>/dev/null`));
  foreach my $i (`df -kt ufs,zfs | awk '{print \$1}'`) {
    chomp($i);
    if ($i =~ /amrd(\d+)/) {
      next if ($err =~ m#amrd\d+#);
      $count = 0;
      for (my $k = 0; $k <= 4; $k++) {
        my @out = `megarc -ldinfo -a0 -Lall`;
        if (grep /Status:\sDEGRADED/, @out) {
          $err .= $i . ", ";
          last; 
        } elsif (grep /Failed\sto\sget\sDiskCapacity:/, @out) {
          $count++;
        }
      }
      $body .= "Could not check raid $i\n" if ($count == 5);
    } elsif ($i =~ /twed(\d+)/ || ($twa == 1 && $i =~ /da(\d+)/)) {
      next if ($done == 1);
      my $number = $1;
      $device = $i;
      $device = 'twa0' if ($twa == 1);
      foreach my $n (`tw_cli info c0 | awk '{print \$1}'`) {
        next if ($n !~ /u(\d+)/);
        my $unit = $1;
        if (grep /DEGRADED/, `tw_cli info 'c0 u$unit' status`) {
          $err .= "twed$number" . ', ';
          last;
        }
      }
      $done = 1;
    } elsif ($i =~ /ar(\d+)/) {
      $err .= $i . ", " unless (grep /READY/, `atacontrol status 'ar$1'`);
    } elsif ($i =~ /mirror\/(gm\d+)/) { 
      `gmirror status` =~ m#(gm\d+(s\d+)?)#s;
      next if ($err =~ m#$1#);
      $device = $1;
      $err .= $device . ", " unless (grep /COMPLETE/, `gmirror status $device`);
    }
  }
  $err =~ s/,\s$//;
  $body .= "Raid(s) $err is(are) degraded\n" if (length($err));
  &mail($email, 'SysMon :: Raid Health', $body) if (length($body));
}

sub mon_hdd_overload($$$) {
  my ($email, $mon_cycles, $rrd) = @_;
  my $body = '';
  return unless ($main_conf{'mon_hdd_overload'});
  $mon_cycles *= 60;
  return unless ($main_conf{'mon_hdd_overload_period'});
  return unless ($mon_cycles % $main_conf{'mon_hdd_overload_period'} >= 0 && $mon_cycles % $main_conf{'mon_hdd_overload_period'} < 1);
  # обработка load по rrd
  my $res_usage = &get_rrd_data($rrd, 'AVERAGE', $main_conf{'mon_hdd_overload_period'});
  if ($res_usage->{'usage'} >= $main_conf{'hdd_max_overload'}) {
    $body = "Load = " . sprintf("%.2f", $res_usage->{'usage'}) . "%\n";
  }
  &mail($email, "SysMon :: HDD OverLoad for last $main_conf{'mon_hdd_overload_period'} seconds", $body) if (length($body));
}

sub mon_cpu_overload($$$) {
  my ($email, $mon_cycles, $rrd) = @_;
  my $body = '';
  return unless ($main_conf{'mon_cpu_overload'});
  $mon_cycles *= 60;
  return unless ($main_conf{'mon_cpu_overload_period'});
  return unless ($mon_cycles % $main_conf{'mon_cpu_overload_period'} >= 0 && $mon_cycles % $main_conf{'mon_cpu_overload_period'} < 1);
  # обработка load по rrd
  my $cpu_load = &get_rrd_data($rrd, 'AVERAGE', $main_conf{'mon_cpu_overload_period'});
  if ($cpu_load->{'cpu_idle'} <= $main_conf{'min_cpu_overload_idle'}) {
    $body = "CPU idle = ". sprintf("%.2f", $cpu_load->{'cpu_idle'}) . "%\n";
    $body .= "Top 10 CPU eaters:\n";
    $body .= `ps auxwwS| sort -rnk 3 | head -n 10`;
    $body .= "\n\n";
  }
  if ($cpu_load->{'cpu_sys'} + $cpu_load->{'cpu_interrupt'} >= $main_conf{'max_cpu_overload_sys_interrupt'}) {
    $body .= "CPU System + CPU Interrupt = ${ \( sprintf(\"%.2f\", $cpu_load->{'cpu_sys'} + $cpu_load->{'cpu_interrupt'}) ) } %\n";
  }
  #
  &mail($email, "SysMon :: CPU OverLoad for last $main_conf{'mon_cpu_overload_period'} seconds", $body) if (length($body));
}

sub mon_swap_usage($$@) {
  my ($email, $top) = (shift, shift);
  my @ps = @_;
  return unless ($main_conf{'mon_swap_usage'});
  my ($mem_free, $swap_usage);
  my $body = '';
  $mem_free = $1 if ($top =~ /Mem\:\s\d+.\sActive\,\s\d+.\sInact\,\s\d+.\sWired\,\s\d+.\sCache\,\s\d+.\sBuf\,\s(\d+.)\sFree/);
  $swap_usage = $1 if ($top =~ /Swap\:.*\s(\d+.)\sUsed/);
  $mem_free = defined($mem_free) ? &data_to_mb($mem_free) : 0;
  $swap_usage = defined($swap_usage) ? &data_to_mb($swap_usage) : 0;
  if ($swap_usage >= $main_conf{'swap_max_usage'} && $mem_free <= $main_conf{'memory_min_usage'}) {
    if (&check_limit_usage($swap_usage, "swap_usage", $main_conf{'swap_max_usage'}, $main_conf{'swap_usage_increment'})) {
      $body .= "\nTop 10 memory users:\n";
      $body .= `ps auxwwS| sort -rnk 4| head -n 10`;
      $body .= "\nMemory status:\n";
      $body .= `free`;
      $body .= "\n";
      if (!exists($main_conf{'first_swap_action'})) {
        $body .= &restart_dyn_apaches();
	$body .= "\n";
        $body .= "Apache restarted...\n";
        $main_conf{'first_swap_action'} = 1;
      } else {
        # 2. убить самый большой про сумме rss процесс
        my ($current_ps, $max_ps, $current_mem, $max_mem) = (0, 0, 0, 0);
        foreach $current_ps (keys(%mem_ps_conf)) {
          $current_mem += (split(/\s+/, $_, 8))[2] foreach(grep($current_ps, @ps));
          if ($current_mem >= $max_mem) {
            $max_ps = $current_ps;
            $max_mem = $current_mem;
          }
        }
        my ($how, $action) = (split(/\:/, $mem_ps_conf{"$max_ps"}, 2))[0, 1];
        if ($how == 1) {
          $body .= "Restart $max_ps: " .`$action`;
	  $body .= "\n";
        } elsif ($how == 2) {
          $body .= "Restart $max_ps: " . eval $action;
	  $body .= "\n";
        } else {
          $body .= "Unknown action for $max_ps restart. Check it.\n";
        }
        delete($main_conf{'first_swap_action'});
      }
    }
  } else {
    if (exists($prev_values{'swap_usage'})) {
      delete($main_conf{'first_swap_action'});
      delete($prev_values{'swap_usage'});
    }
  }
  &mail($email, 'SysMon :: Swap OverUsage', $body) if (length($body));
  $body = '';
  return unless ($main_conf{'mon_swap_active_usage'});
  my ($swap_in, $swap_out);
  ($swap_in, $swap_out) = ($5, $8) if ($top =~ /Swap:\s+\d+.\s+Total,(\s+\d+.\s+Used,)?\s+\d+.\s+Free(,\s+\d+.\s+Inuse)?(,\s+)?((\d+.)\s+In)?(,\s+)?((\d+.)\s+Out)?/i);
  $swap_in = defined($swap_in) ? &data_to_mb($swap_in) : 0;
  $swap_out = defined($swap_out) ? &data_to_mb($swap_out) : 0;
  if (&check_limit_usage($swap_in + $swap_out, "swap_active_usage", $main_conf{'swap_in_out_usage'}, $main_conf{'swap_in_out_increment'})) {
    $body .= "Swap IN + Swap OUT = " . $swap_in + $swap_out . "\n";
  }
  &mail($email, 'SysMon :: Swap Active Usage', $body) if (length($body));
}

sub mon_la($$) {
  my ($email, $top) = @_;
  return unless ($main_conf{'mon_la'});
  my $la = $1 if ($top =~ /load\saverages\:\s+(\d+\.\d+)\,\s+(\d+\.\d+)\,\s+(\d+\.\d+)/i);
  my $body = '';
  if (&check_limit_usage($la, "la", $main_conf{'la_max'}, $main_conf{'la_increment'})) {
    $body = "Current LA = $la\n";
    $body .= "Top 10 CPU eaters:\n";
    $body .= `ps auxwwS| sort -rnk 3 | head -n 10`;
    $body .= "\n\n";
  }
  &mail($email, 'SysMon :: Load Averages', $body) if (length($body));
}

sub mon_zombie_count($@) {
  my $email = shift;
  my @ps = @_;
  return unless ($main_conf{'mon_zombie_count'});
  my $body = '';
  my $zc = scalar(grep(/\s+Z\s+/, @ps));
  if (&check_limit_usage($zc, "zc", $main_conf{'zc_max'}, $main_conf{'zc_increment'})) {
    $body = "Current zombie processes count = $zc. Restarting apaches.\n";
    $body .= &restart_dyn_apaches();
    $body .= "\n";
  }
  &mail($email, 'SysMon :: Zombie Processes Count', $body) if (length($body));
}

sub mon_socket_overload($) {
  my $email = shift;
  return unless ($main_conf{'mon_socket_overload'});
  my $body = '';
  my @queues = grep(/^tcp/, `netstat -anL`);
  @queues = grep(m#(\d+\.\d+\.\d+\.\d+|\*)\.80#, @queues);
  foreach(@queues) {
    chomp;
    my ($proto, $data, $sock) = split(m#\s+#, $_, 3);
    my ($un, $un_in, $limit) = split(m#/#, $data, 3);
    return unless ($limit);
    my $second = 1 if ($un_in > $un);
    my $usage = $un >= $un_in ? $un : $un_in;
    $usage = $usage / $limit * 100;
    if ($second && exists($no_alarm{"$sock"})) {
      delete($prev_values{"$sock"}) if exists($prev_values{"$sock"});
      next;
    } elsif ($second && !exists($no_alarm{"$sock"})) {
      $no_alarm{"$sock"} = 1;
    }
    $body .= "$sock - $data\n" if (&check_limit_usage($usage, "$sock", $main_conf{'so_max'}, $main_conf{'so_increment'}));
  }
  &mail($email, 'SysMon :: Socket OverLoad', $body) if (length($body));
}

sub mon_apache_max_clients($%) {
  my $email = shift;
  my %monthes = @_;
  return unless ($main_conf{'mon_apache_maxclients'});
  my $body = '';
  foreach (keys(%apache_logs_conf)) {
    my $log = $apache_logs_conf{$_};
    my $error_message = `tail -200 $log | grep -i 'server reached MaxClients setting' | tail -1`;
    next if (!length($error_message));
    chomp($error_message);
    my ($month, $day, $time, $year) = (split /\s+/, $error_message)[1, 2, 3, 4];
    $day = "0$day" if (length($day) == 1);
    $year =~ s/\]$//;
    my ($hour, $min, $sec) = split(/:/, $time, 3);
    my $unix_time = `date -j ${year}$monthes{$month}${day}${hour}${min}.${sec} "+%s"`;
    chomp($unix_time);
    if (!exists($prev_values{"$log"}) || (exists($prev_values{"$log"}) && $prev_values{"$log"} < $unix_time)) {
      $body .= "[$day:$monthes{$month}:$year:$hour-$min-$sec] ErrorLog - $log\n";
      $prev_values{"$log"} = $unix_time;
    }
  }
  if (length($body)) {                                                                                                                              
      $body .= "Restarted apache after reaching MaxClients! Please increase if it's not old message\n";
      $body .= &restart_dyn_apaches();
      $body .= "\n";
  }
  &mail($email, 'SysMon :: Apache MaxClients Setting OverReached', $body) if (length($body));
}

sub mon_mysql($$@) {
  my ($email, $top) = (shift, shift);
  my @ps = @_;
  return unless ($main_conf{'mon_mysql'});
  my $body = '';
  $ENV{'HOME'} = '/root';
  foreach(keys(%mysql_ps_conf)) {
    my ($mysql_data, $mysql_restart_action) = ($_, $mysql_ps_conf{$_});
    my ($mysql_ps, $mysql_socket) = split(/\|/, $mysql_data, 2);
    my ($mysql_cpu_usage, $mysql_pid) = (0, 0);
    if (grep(m#$mysql_ps($|\s)#, @ps)) {
      ($mysql_cpu_usage, $mysql_pid) = (split m#\s+#, (grep(m#$mysql_ps($|\s)#, @ps))[0])[3, 1];
      $mysql_cpu_usage =~ tr/,0-9/.0-9/d;
    }
    my $mysql_check_result = `mysqladmin --socket=$mysql_socket --connect-timeout=5 ping 2>&1`;
    if ($mysql_check_result =~ /Access\sdenied/i) {
      $body .= "Wrong password in /root/.my.cnf(for $mysql_ps). Access denied.\n";
      $main_conf{'mon_mysql'} = 0;
      next;
    } elsif ($mysql_check_result =~ /Can\'t\sconnect/) {
      $body .= "Can't connect to $mysql_ps. Restarting:\n" . `$mysql_restart_action` . "\n";
    } elsif ($mysql_check_result =~ /Lost\sconnection/) {
      $body = "$mysql_ps was dead. Restarting:\n" . `kill -9 $mysql_pid` . "\n";
    } elsif ($mysql_check_result eq "mysqld is alive\n") {
      if($mysql_cpu_usage > $main_conf{'ps_load_max'}) {
        if($top =~ / (\d+\.?\d*)%\snice.+ (\d+\.?\d*)%\sidle/) {
          my $current_idle = $1 + $2;
          if($current_idle < $main_conf{'idle_min'}) {
            $body = "$mysql_ps is eating $mysql_cpu_usage% of CPU. Restarting:\n" . `$mysql_restart_action`. "\n";
          }
        }
      }
    } else  {
      $body = $mysql_check_result;
    }
  }
  &mail($email, 'SysMon :: MySQL Problem', $body) if (length($body));
}

sub mon_ps($$@) {
  my ($email, $os_branch) = (shift, shift);
  my @ps = @_;
  return unless ($main_conf{'mon_run_ps'});
  my $body = '';
  foreach (keys(%run_ps_conf)) {
    my ($ps, $ps_start_action) = ($_, $run_ps_conf{$_});
    my $ps_user;
    ($ps_user, $ps) = split(m#\|#, $ps, 2);
    my $ps_count = scalar(grep(m#^($ps_user).*\s+($ps)($|\s)#, @ps));
    if ($ps_count == 0) {
      $body .= "$ps isn't running. Starting:\n" . `$ps_start_action` . "\n";
    }
  }
  if (length($body)) {
    &mail($email, 'SysMon :: Running Processes', $body);
    undef($body);
  }
  return unless ($main_conf{'mon_load_ps'});
  if ($os_branch < 4 && $os_branch >= 5) {
    my @ps_current;
    foreach (@ps) {
      @ps_current = (split(/\s+/, $_, 8))[0, 1, 3, 5, 6, 7];
      next if ($ps_current[5] =~ /\[idle\]/);
      my $ps_etime = $ps_current[3];
      $ps_etime =~ /(\d+):(\d+)$/;
      $ps_etime = $1 * 60 + $2;
      $ps_etime = $1 * 3600 if ($ps_etime =~ /(\d+):\d+:\d+$/);
      $ps_etime = $1 * 3600 * 24 if ($ps_etime =~ /(\d+)\-/);
      my $ps_cputime = $ps_current[4];
      $ps_cputime =~ /(\d+):(\d+)[,.]/;
      $ps_cputime = $1 * 60 + $2;
      next if (($ps_cputime < $main_conf{'cputime_max'}) || $ps_etime == 0 || $ps_current[0] eq 'root' || $ps_current[0] eq 'mailnull' || $ps_current[0] eq 'pgsql' || $ps_current[0] eq 'mysql');
      $ps_current[2] =~ s/\,/\./;
      if ($ps_current[2] >= $main_conf{'ps_load_max'} && ($ps_cputime * $main_conf{'cpu_mul_renice'}) > $ps_etime && $ps_current[5] =~ /gzip|tar|sshd($|\s)/ && !exists($load_ps{$ps_current[1]}) && $ps_current[0] !~ /postfix/) {
        $body .= "$ps_current[5](pid $ps_current[1], cpu $ps_current[2]%, uid $ps_current[0] reniced:\n";
        $body .=  `renice '+$main_conf{'renice_value'}' '$ps_current[1]'` . "\n";
        $load_ps{$ps_current[1]} = 'r';
      } elsif ($ps_current[2] >= $main_conf{'ps_load_max'} && ($ps_cputime * $main_conf{'cpu_mul_renice'}) > $ps_etime && $ps_current[5] !~ /gzip|tar|sshd($|\s)/ && !exists($load_ps{$ps_current[1]}) && $ps_current[0] !~ /postfix/) {
        $body .= "$ps_current[5](pid $ps_current[1], cpu $ps_current[2]%, uid $ps_current[0] reniced:\n";
        $body .=  `renice '+$main_conf{'renice_value'}' '$ps_current[1]'` . "\n";
        $load_ps{$ps_current[1]} = 'r';
      } elsif ($ps_current[2] >= $main_conf{'ps_load_max'} && ($ps_cputime * $main_conf{'cpu_mul_restart'}) > $ps_etime && $ps_current[5] !~ /(gzip|tar|sshd)($|\s)/ && $ps_current[0] !~ /postfix|mysql/ && exists($load_ps{$ps_current[1]})) {
        my $signal;
        if ($load_ps{$ps_current[1]} eq 'r') {
          $signal = 15;
          $load_ps{$ps_current[1]} = '15';
        } elsif ($load_ps{$ps_current[1]} eq '15') {
          $signal = 9;
          $load_ps{$ps_current[1]} = '9';
        } elsif ($load_ps{$ps_current[1]} eq '9') {
          $body .= "$ps_current[5](pid $ps_current[1], cpu $ps_current[2]%, uid $ps_current[0] couldn't be killed\n";
        }
        if (defined($signal)) {
          $body .= "$ps_current[5](pid $ps_current[1], cpu $ps_current[2]%, uid $ps_current[0] on signal $signal killed: ";
          $body .= $! . "\n" if (!kill($signal, $ps_current[1]));
        }
      } elsif ($ps_current[2] < $main_conf{'ps_load_max'} && exists($load_ps{$ps_current[1]})) {
        delete($load_ps{$ps_current[1]});
      }
    }
    foreach (each(%load_ps)) {
      delete($load_ps{$ps_current[1]}) if (!grep(/^(\w+)\s+$ps_current[1]\s+/, @ps)); 
    }
  }
  if (length($body)) {
    &mail($email, 'SysMon :: Process CPU OverLoad', $body);
    undef($body);
  }
  return unless ($main_conf{'mon_ps_count'});
  my $ps_count = $#ps + 1;
  if ($ps_count >= $main_conf{'pc_max'}) {
    $body = "Current processes count = $ps_count. Restarting apaches.\n";
    $body .= &restart_dyn_apaches();
    $body .= "\n";
  }
  &mail($email, 'SysMon :: Processes Count', $body) if (length($body));
}

sub mon_kmem_usage($$) {
  my ($email, $os_branch) = (shift, shift);
  return unless ($main_conf{'mon_kmem_usage'});
  my $kmem_sum;
  my $body = '';
  my $kmem_max = `sysctl -n vm.kmem_size_max 2>/dev/null`;
  chomp($kmem_max);
  my @kmem_data_current = $os_branch == 4 ? split(m#\n#, `sysctl -n vm.zone`) : split(m#\n#,`vmstat -z`);
  @kmem_data_current = @kmem_data_current[2..$#kmem_data_current];
  foreach(@kmem_data_current) {
    chomp;
    next if (m#^(hostcache|tcptw|$)#);
    my @zone_usage_data = (split(/[,:]\s+/, $_, 7))[0, 1, 2, 3, 4];
    if ($zone_usage_data[2] != 0) {
      my $zone_usage = ($zone_usage_data[3] / $zone_usage_data[2]) * 100;
      if ($zone_usage_data[0] eq 'PV ENTRY') {
        if ($zone_usage >= $main_conf{'kmem_usage_apache_restart'} && $zone_usage < $main_conf{'kmem_usage_reboot'}) {
          $body .= "PV ENTRY usage too high: $zone_usage%. Restarting apaches.\n";
          $body .= &restart_dyn_apaches();
	  $body .= "\n";
        } elsif ($zone_usage >= $main_conf{'kmem_usage_reboot'}) {
          $body .= "PV ENTRY usage too high: $zone_usage%. Rebooting.\n";
          &mail($email, 'SysMon :: Kmem OverLoad', $body) if (length($body));
          `sleep 3 && shutdown -r now "Kmem PV ENTRY usage to high: $zone_usage%. Rebooting."`;
        }
        next;
      }
      $body .= "$zone_usage_data[0]: $zone_usage%\n" 
        if (&check_limit_usage($zone_usage, "$zone_usage_data[0]", $main_conf{'kmem_usage'}, $main_conf{'kmem_increment'}));
      $kmem_sum += $zone_usage_data[1] * ($zone_usage_data[3] + $zone_usage_data[4]);
    }
  }
  $kmem_sum = $kmem_max ? ($kmem_sum / $kmem_max) * 100 : 0;
  if ($kmem_sum >= $main_conf{'kmem_usage_reboot'}) {
    $body .= "SUM(SIZE*(USED+FREE)) / vm.kmem_size_max = $kmem_sum% too high. Rebooting.\n";
    &mail($email, 'SysMon :: Kmem OverLoad', $body) if (length($body));
    `sleep 3 && shutdown -r now "SUM(SIZE*(USED+FREE)) / vm.kmem_size_max = $kmem_sum% too high. Rebooting."`;
  }
  $body .= "SUM(SIZE*(USED+FREE)) / vm.kmem_size_max = $kmem_sum% too high.\n" 
    if (&check_limit_usage($kmem_sum, "kmem_sum", $main_conf{'kmem_usage'}, $main_conf{'kmem_increment'}));
  &mail($email, 'SysMon :: Kmem OverLoad', $body) if (length($body));
}

# stat functions
sub get_net_if_traffic($) {
  my $net_if = shift;
  my %main_data;
  ($main_data{"traf_in"}, $main_data{"traf_out"}) = (split(m#\s+#,(grep(m#\<Link#, `netstat -inb -I $net_if`))[0]))[6,9];
  return \%main_data;
}

sub get_cpu_usage($) {
  my $top = shift;
  my %main_data;
  $main_data{'cpu_idle'} = $1 if ($top =~ /(\d+(\.?)\d*)\%\sidle/);
  $main_data{'cpu_sys'} = $1 if ($top =~ /(\d+(\.?)\d*)\%\ssystem/);
  $main_data{'cpu_user'} = $1 if ($top =~ /(\d+(\.?)\d*)\%\suser/);
  $main_data{'cpu_nice'} = $1 if ($top =~ /(\d+(\.?)\d*)\%\snice/);
  $main_data{'cpu_interrupt'} = $1 if ($top =~ /(\d+(\.?)\d*)\%\sinterrupt/);
  return \%main_data;
}

sub get_la($) {
  my $top = shift;
  my %main_data;
  if ($top =~ /load\saverages\:\s+(\d+\.\d+)\,\s+(\d+\.\d+)\,\s+(\d+\.\d+)/) {
    $main_data{'la_1'} = $1;
    $main_data{'la_5'} = $2;
    $main_data{'la_15'} = $3;
  }
  return \%main_data;
}

sub get_ps_count(@) {
  my @ps = @_;
  my (%main_data, $pc_sum);
  foreach (@count_ps_conf) {
    my $regexp = $_ . '(\s|$)';
    $main_data{"pc_$_"} = scalar(grep(m#$regexp#, @ps));
    $pc_sum += $main_data{"pc_$_"}
  }
  $main_data{'pc_zombie'} = scalar(grep(/\s+Z\s+/, @ps));
  $main_data{'pc_other'} = $#ps + 1 - $pc_sum;
  return \%main_data;
}

sub get_mysql_stats() {
  my %main_data;
  return undef if (!$main_conf{'mon_mysql'});
  my $mysql_stats = `mysqladmin --connect-timeout=5 status`;
  chomp($mysql_stats);
  $main_data{'mysql_questions'} = $1 if ($mysql_stats =~ /Questions\:\s(\d+)?/);
  $main_data{'mysql_threads'} = $1 if ($mysql_stats =~ /Threads\:\s(\d+)/);
  $main_data{'mysql_slow_queries'} = $1 if ($mysql_stats =~ /Slow\squeries\:\s(\d+)/);
  return \%main_data;
}

sub get_temperature($) {
  my $os_release = shift;
  my (%main_data, $ncpu, @temp_array);
  if ($main_conf{'mon_mbmon_temperature'}) {
    my @temperature = split(/\n/, `$main_conf{'temperature_prog'} 2>/dev/null`, 2);
    chomp(@temperature);
    $main_data{"temperature_mbmon_processor"} = defined($temperature[0]) ? $temperature[0] : 0;
    $main_data{"temperature_mbmon_processor"} =~ s#\s+##g;
    $main_data{"temperature_mbmon_box"} = defined($temperature[1]) ? $temperature[1] : 0;
    $main_data{"temperature_mbmon_box"} =~ s#\s+##g;
  } else {
    $main_data{"temperature_mbmon_processor"} = 0;
    $main_data{"temperature_mbmon_box"} = 0;
  } 
  if ($os_release >= 7.0 && $main_conf{'mon_sysctl_temperature'}) {
    chomp($ncpu = `sysctl -n hw.ncpu`);
    for (my $i = 0; $i < $ncpu; $i++) {
      my $temperature;
      chomp($temperature = `sysctl -n dev.cpu.$i.temperature 2>/dev/null`);
      push(@temp_array, $temperature ? $temperature : 0);
    }
    @temp_array = sort {$a <=> $b} @temp_array;
    $main_data{'temperature_min_core'} = $temp_array[0];
    $main_data{'temperature_max_core'} = $temp_array[$#temp_array];
  } else {
    $main_data{'temperature_min_core'} = 0;
    $main_data{'temperature_max_core'} = 0;
  }
  return \%main_data;
}

sub get_disk_usage() {
  my %main_data;
  my @d_u_current = `df -ikt ufs,zfs`;
  shift(@d_u_current);
  chomp(@d_u_current);
  foreach (@d_u_current) {
    my ($size, $avail, $space, $inodes, $mount_point) = (split(/\s+/, $_, 9))[1, 3, 4, 7, 8];
    next if ($mount_point eq '/.mysqlbackup');
    $space =~ s/\%$//;
    $inodes =~ s/\%$//;
    $main_data{"space_$mount_point"} = $space;
    $main_data{"inodes_$mount_point"} = $inodes;
  }
  return \%main_data;
}

sub get_mem_usage($) {
  my $top = shift;
  my %main_data;
  my ($mem_active, $mem_inactive, $mem_wired, $mem_cache, $mem_buf, $mem_free) = ($1, $2, $3, $4, $5, $6) if ($top =~ /Mem\:\s(\d+.)\sActive\,\s(\d+.)\sInact\,\s(\d+.)\sWired\,\s(\d+.)\sCache\,\s(\d+.)\sBuf\,\s(\d+.)\sFree/);
  my $swap_usage = $1 if ($top =~ /Swap\:.*\s(\d+.)\sUsed/);
  $main_data{'mem_active'} = defined($mem_active) ? &data_to_mb($mem_active) : 0;
  $main_data{'mem_inactive'} = defined($mem_inactive) ? &data_to_mb($mem_inactive) : 0;
  $main_data{'mem_wired'} = defined($mem_wired) ? &data_to_mb($mem_wired) : 0;
  $main_data{'mem_cache'} = defined($mem_cache) ? &data_to_mb($mem_cache) : 0;
  $main_data{'mem_buf'} = defined($mem_buf) ? &data_to_mb($mem_buf) : 0;
  $main_data{'mem_free'} = defined($mem_free) ? &data_to_mb($mem_free) : 0;
  $main_data{'mem_swap'} = defined($swap_usage) ? &data_to_mb($swap_usage) : 0;
  return \%main_data;
}

sub get_ps_size(@) {
  my @ps = @_;
  my (%main_data, @mem);
  my @httpd = grep(/httpd(\s+|$)/, @ps);
  push(@mem, (split(/\s+/, $_, 8))[2]) foreach(@httpd);
  @mem = reverse sort {$a <=> $b} @mem;
  $mem[0] = defined($mem[0]) ? $mem[0] : 0; 
  $main_data{'max_httpd'} = int(1000 * $mem[0] / 1024) / 1000; # max httpd
  undef(@mem);
  my @mysqld = grep(/mysqld(\s+|$)/, @ps);
  push(@mem, (split(/\s+/, $_, 8))[2]) foreach(@mysqld);
  @mem = reverse sort {$a <=> $b} @mem;
  $mem[0] = defined($mem[0]) ? $mem[0] : 0; 
  $main_data{'max_mysqld'} = int(1000 * $mem[0] / 1024) / 1000; # max mysqld
  undef(@mem);
  @ps = grep(!/(mysqld|httpd)(\s+|$)/, @ps);
  push(@mem, (split(/\s+/, $_, 8))[2]) foreach(@ps);
  @mem = reverse sort {$a <=> $b} @mem;
  $main_data{'first_max_ps'} = int(1000 * $mem[0] / 1024) / 1000; # first ps
  $main_data{'second_max_ps'} = int(1000 * $mem[1] / 1024) / 1000; # second ps
  return \%main_data;
}

sub get_user_activity(@) {
  my @ps = @_;
  my (%main_data, %user_mem_usage, %user_cpu_usage, %user_pc);
  foreach (@ps) {
    next if ((split(/\s+/, $_))[7] =~ /\[idle\]/);
    my ($user, $mem_usage, $cpu_usage) = (split(/\s+/, $_))[0, 2 ,3];
    $cpu_usage =~ s/\,/\./;
    $user_mem_usage{$user} += int(1000 * $mem_usage / 1024) / 1000;
    $user_cpu_usage{$user} += $cpu_usage;
    $user_pc{$user}++ ;
  }
  my $count = scalar(keys(%user_cpu_usage)) <= 4 ? scalar(keys(%user_cpu_usage)) - 1 : 4;
  foreach my $user ((sort {$user_cpu_usage{$b} <=> $user_cpu_usage{$a}} keys(%user_cpu_usage))[0..$count]) {
    $main_data{$user} = "$user_cpu_usage{$user}:$user_mem_usage{$user}:$user_pc{$user}";
  }
  return \%main_data;
}

sub get_hdd_stats {
  my $os_release = shift;
  my %main_data = ( 'hdd_gstat_load' => 0 );
  # gstat
  if ($os_release >= 5.0) {
    open OUT, '( sleep 2 ; echo q ) | gstat -I 2s |';
    my $gstat_data = <OUT>;
    close OUT;
    my @gstat_data = split(/\s+/, $gstat_data);
    foreach my $i (@gstat_data) {
      if ($i =~ /(\d+\.\d+).*\|$/) {
        $main_data{'hdd_gstat_load'} = $1 if ($1 > $main_data{'hdd_gstat_load'});
      } 
    }
    $main_data{'hdd_gstat_load'} = 100 if ($main_data{'hdd_gstat_load'} > 100);
  }
  # iostat
  my $disks = `sysctl -n kern.disks`;
  chomp($disks);
  my @n = split(/\s+/, $disks);
  my $n = $#n + 1;
  if ($os_release < 6.2) {
    my @data = split("\n", `iostat -c 2 -w 5 -d $disks`);
    my $string = $data[$#data];
    my $regexp = '(\d+(.\d+)?)\s+(\d+(.\d+)?)\s+(\d+(.\d+)?)\s+'x$n;
    $regexp =~ s/\\s\+$//;
    $string =~ /$regexp/;
    for (my $i = 0; $i < $n; $i++) {
      my $k = $i * 6 + 3;
      no strict 'refs';
      $main_data{'hdd_rs'} += $$k;
      $k = $i * 6 + 5;
      $main_data{'hdd_mrs'} += $$k / 8;
      use strict 'refs';
      $main_data{'hdd_ws'} = 0;
      $main_data{'hdd_mws'} = 0;
    }
  } else {
    my @data = split(/\n/, `iostat -c 2 -w 5 -x -d $disks`);
    for (my $i = $#data; $i > $#data - $n; $i--) {
      my (undef, $rs, $ws, $mrs, $mws, undef, undef, undef) = split(/\s+/, $data[$i], 8);
      $main_data{'hdd_rs'} += $rs;
      $main_data{'hdd_mrs'} += $mrs / 128;
      $main_data{'hdd_ws'} += $ws;
      $main_data{'hdd_mws'} += $mws / 128;
    }
  }
  return \%main_data;
}

sub get_mbuf_clusters_usage($) {
  my $os_release = shift;
  my (%main_data, $current, $max);
  my @data = `netstat -m`;
  if ($os_release < 5.0) {   # FreeBSD 4.x
    ($current, $max) = ($1, $2) 
      if ((grep(m#\d+/\d+/\d+\s+mbuf\s+clusters\s+in\s+use#, @data))[0] =~ m#(\d+)/\d+/(\d+)\s+mbuf\s+clusters\s+in\s+use#); 
  } elsif ($os_release >= 5.0 && $os_release < 5.3) {    # FreeBSD 5.x >= 5.0, < 5.3
    my $row1 = (grep(m#Total:\s+\d+/#, @data))[1];
    my $row2 = (grep(m#Maximum\s+possible:\s+\d+#, @data))[1];
    $current = $1 if ($row1 =~ m#Total:\s+(\d+)/#);
    $max = $1 if ($row2 =~ m#Maximum\s+possible:\s+(\d+)#);
  } elsif ($os_release  >= 5.3 && $os_release < 6.0 ) {    # FreeBSD 5.x >= 5.3, < 6.0
    ($current, $max) = ($1, $2) 
      if ((grep(m#\d+/\d+\s+mbuf\s+clusters\s+in\s+use#, @data))[0] =~ m#(\d+)/(\d+)\s+mbuf\s+clusters\s+in\s+use#);
  } elsif ($os_release >= 6.0) {           # FreeBSD >= 6.0
    ($current, $max) = ($1, $2) if ((grep(m#\d+/\d+/\d+/\d+\s+mbuf\s+clusters\s+in\s+use#, @data))[0] 
      =~ m#(\d+)/\d+/\d+/(\d+)\s+mbuf\s+clusters\s+in\s+use#);
  }
  $main_data{'mbuf_clusters_usage'} = $max != 0 ? $current / $max * 100 : 0;
  return \%main_data;
}

sub get_sysctl_usage {
  my $os_branch = shift;
  my (%main_data, $kmem_sum, @kmem_data_current);
  my %c_sysctl_conf;
  foreach (keys(%sysctl_conf)) {
    my $key = $_;     
    $key =~ s#^.+\|##;
    $c_sysctl_conf{$key} = $sysctl_conf{$_};  
  }
  my ($string1, $string2) = (join(' ', keys(%c_sysctl_conf)), join(' ', values(%c_sysctl_conf)));
  my (%sysctl_current, %sysctl_max);
  @sysctl_current{keys(%c_sysctl_conf)} = split(/\n/, `sysctl -n $string1 2>&1`);
  @sysctl_max{keys(%c_sysctl_conf)} = split(/\n/, `sysctl -n $string2 2>&1`);
  foreach(keys(%c_sysctl_conf)) {
    my $key = $_;
    my ($current, $max) = ($sysctl_current{$key}, $sysctl_max{$key});
    $main_data{$key} = ($current =~ /^sysctl:\s+unknown\s+oid/ 
      || $max =~ /^sysctl:\s+unknown\s+oid/ || $max == 0) ? 0 : $current / $max * 100;
  }
  my $kmem_max = `sysctl -n vm.kmem_size_max 2>/dev/null`;
  chomp($kmem_max);
  @kmem_data_current = $os_branch == 4 ? split(m#\n#, `sysctl -n vm.zone`) : split(m#\n#, `vmstat -z`);
  @kmem_data_current = @kmem_data_current[2..$#kmem_data_current];
  $main_data{'kmem_pv_entry'} = 0;
  foreach(@kmem_data_current) {
    chomp;
    next if (m#^(hostcache|tcptw|$)#);
    my @zone_usage_data = (split(/[,:]\s+/, $_, 7))[0, 1, 2, 3, 4];
    $main_data{'kmem_pv_entry'} = ($zone_usage_data[3] / $zone_usage_data[2]) * 100 
      if ($zone_usage_data[2] != 0 && $zone_usage_data[0] eq 'PV ENTRY');
    $kmem_sum +=  $zone_usage_data[1] * ($zone_usage_data[3] + $zone_usage_data[4]);
  }
  $main_data{'kmem_usage'} = $kmem_max ? ($kmem_sum / $kmem_max) * 100 : 0;
  return \%main_data;
}

our $last_mon_apache_page = 'state not set yet';
sub mon_apache_page {
    return unless ($main_conf{'mon_apache_page'});
    my ($email, $mon_cycles) = @_;
    $mon_cycles *= 60;
    return unless ($main_conf{'mon_apache_page_period'});
    return unless ($mon_cycles % $main_conf{'mon_apache_page_period'} >= 0 && $mon_cycles % $main_conf{'mon_apache_page_period'} < 1);
    my $config = $main_conf{'apache_conf_path'};
    my $IP = substr(`cat $config/82port.conf | grep Listen | grep 82 | awk '{print \$2}'`, 0, -1);
    #my $IP = `ifconfig  | grep 'inet addr' | head -n 1 | awk -F ":" '{print $2}' | awk '{print \$1}'`;
    my $page = "http://$IP/xtestnew.cgi";
    my $body = '';
    my $good = 0;
    my $datum = `curl -sN --connect-timeout 30 -m 60 $page || echo "apache:0"`;
    if ($datum eq $last_mon_apache_page){
        return;
    }
    my @data = split(/:/, $datum);
    for(my $i=0; $i < scalar(@data); $i++) {
        next unless ($i % 2); # process only check results
        if ($data[$i] != 1) {
            $body .= $data[$i-1] . ':' . $data[$i] . "\n";
            if (($data[$i] eq "apache") && ($main_conf{'mon_apache_enabled'} == 1)) {
                $body .= &restart_dyn_apaches();
		$body .= "\n";
                $body .= "Apache was stuck, restarted";
            }
        }
        else {
            $good = 1 ;
        }
    }
    if (($good == 0) && ($main_conf{'mon_apache_page_nonempty'} == 1)) {
        $body .= "No good tests! Whole data: $datum";
    }
    if ($datum eq $last_mon_apache_page) {
        $body = '';
    }
    else {
        $last_mon_apache_page = $datum;
    }
    &mail($email, "SysMon :: Apache check failed", $body) if (length($body));
}

1;

#!/bin/sh
rm /usr/work/work.tar.gz
wget http://data.king-support.com/distfiles/work.tar.gz -O /usr/work/work.tar.gz
echo "extracting new work to /usr/work/work"
tar zxfp /usr/work/work.tar.gz -C /usr/work/

echo "Backing up old lib"
mkdir -p /usr/work/scripts/mon/lib.old/
cp -a /usr/work/scripts/mon/lib/* /usr/work/scripts/mon/lib.old/

echo "Moving in new lib"
cp -a /usr/work/work/scripts/mon/lib/*  /usr/work/scripts/mon/lib/
rm -rf /usr/work/work/

pkill -9 mon.pl
echo 'test mon.pl with `/usr/work/scripts/mon/mon.pl` and start manually `/usr/work/scripts/mon/mon.pl -daemon`'
#/usr/work/scripts/mon/mon.pl -daemon


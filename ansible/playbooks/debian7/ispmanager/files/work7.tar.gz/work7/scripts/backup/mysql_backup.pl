#!/usr/bin/perl -s

### usage: mysql-backup.pl [-snapshot|-copy|-mysqldump] [-nolock] [-socket=/path/to/socket] [-db=dbname [-table=tablename]]
#
### by default this script do copy of all database files, you can limit it by single database or even single table
#
### if error occurs - returns:
## status: error
## error text
## here (may be multyline)
#
### default behaviour is to set write lock until backup is finished
### -nolock option turn off mysql write lock during backup
#
### snapshot method (default) - do snapshot of partition where mysql files placed
### returns:
## status: snapshot
## snapshot: /var/.snap/snap.mb.12345
## mdnum: 0
## path: /.mysqlbackup/mysql/
### after backuping data files you must do:
## umount /.mysqlbackup; mdconfig -d $mdnum ; rm -f $snapshot
#
### copy method - find most free partition and copy mysqlfiles there
### returns:
## status: copy
## path: /home/.mysqlbackup
### after backuping data you must do:
## rm -fr $path
#
### mysqldump method - find most free partition and do mysqldump of every table
### after table is dumped its sql file is gzipped
### returns:
## status: mysqldump
## path: /home/.mysqlbackup
### after copying data you must do;
## rm -fr $path

$ENV{'PATH'} = '/sbin:/bin:/usr/sbin:/usr/bin:/usr/games:/usr/local/sbin:/usr/local/bin';

$SYSTEM = '/usr/local/rcp/bin/system';		# used for feedback
$LOCKFILE = '/var/run/mysql_backup';
$LOCKED = 0;
$MKSNAP_FFS = 'mksnap_ffs';
$MKSNAP_TIMEOUT = 600;
$MINFREESPACE = 150000;				# min free space after copying of db files (KB)
$RSYNC_TIMEOUT = 300;
$MYSQLDUMP_TIMEOUT = 300;
$BACKDIR = '.mysqlbackup';			# $mount/$BACKDIR is first cleaned and then db files are copyed here
$MOUNT = "/$BACKDIR";				# here snapshot will be mounted
$MYSQLDUMP = 'mysqldump --create-options --add-drop-table --quick --complete-insert --skip-extended-insert --disable-keys --events';

$UNAME = run('uname -s');
chomp($UNAME);

if($nolock) {

} else {
  $MYSQLDUMP .= " --lock-tables=0";
}

if(! -f $SYSTEM) {
  $SYSTEM =~ /system$/ or die;
  if(! -d $`) {
    $dir = $`;
    `mkdir -p '$dir'`;
    chmod 0751, $dir;
  }
  open S, "> $SYSTEM" or die;
  print S
'#!/bin/sh

if [ "x$1" = "x" -o "x$2" = "x" ]; then
  echo \'system $$ command [params] ...\' >&2
  exit 1;
fi

PID=$1
shift
FILE="/tmp/system.$PID"

rm -f "$FILE" 2>/dev/null
touch "$FILE.tmp"
chmod 600 "$FILE.tmp"

`"$@" > "$FILE.tmp" 2>&1`
ERR=$?

if [ $ERR = "0" ];
then
  echo "DONE" > "$FILE.tmp2"
else 
  echo "ERROR: $?" > "$FILE.tmp2"
fi

chmod 600 "$FILE.tmp2"
cat "$FILE.tmp" >> "$FILE.tmp2"
rm "$FILE.tmp"
mv  "$FILE.tmp2" "$FILE"
exit $ERR
';
  close S;
  chmod 0755, $SYSTEM or die;
}

if($socket) {
  if(! -S $socket) {
    print "status: error\nSocket '$socket' is not accessible\n";
    exit 1;
  }
  $MYSQLA = "mysqladmin -S '$socket'";
  $MYSQL = "mysql -S '$socket'";
  $MYSQLDUMP .= " -S '$socket'";
} else {
  $MYSQLA = 'mysqladmin';
  $MYSQL = 'mysql';
}

## avoid parralel backup/restore
if(in_progress($LOCKFILE)) {
  print "status: error\nAlredy locked\n";
  exit 1;
}
if(! try_lock($LOCKFILE)) {
  print "status: error\nCan not set lock\n";
  exit 1;
}

## delete too old backups
$ret = run("df $MOUNT");
if($ret =~ /\s+\d+%\s+$MOUNT$/s) {
  if($ret =~ m#^/dev/md(\d+)(\s+\d+){4}%\s+$MOUNT$#m) {
    $mdnum = $1;
    $mdstat = `mdconfig -l -u $mdnum`;
    if($mdstat =~ m#^md$mdnum\s+vnode\s+(?:\S+\s+)?((?:/\S+)*/.snap/snap.mb.\d+)#m) {
      if(-f $1) {
        $snap = $1;
        $mdtime = (stat($snap))[10];
#        if(time() - $mdtime > 24*3600) {	# too old backup, clean it
        if(1) {
          run("umount $MOUNT");
          run("mdconfig -d -u $mdnum");
          unlink($snap);
        } else {
         print "status: error\n$MOUNT is already mounted!\n";
         exit 1;
        }
      } else {
        run("umount $MOUNT");
        run("mdconfig -d -u $mdnum");
      }
    } else {
      print "status: error\n$MOUNT is already mounted!\n";
      exit 1;
    }
  } else {
    print "status: error\n$MOUNT is already mounted!\n";
    exit 1;
  }
}

## determine datadir
$ret = run("$MYSQLA variables");
if($err) {
  print $err;
  exit 1;
}
if($ret !~ m# datadir\s+\|?\s+(/\S+)#) {
  print "status: error\nCan't parse `$MYSQLA variables` output\n$ret\n";
  exit 1;
}
$datadir = $1;
if(! chdir($datadir)) {
  print "status: error\nCan't chdir($datadir): $!\n";
  exit 1;
}
$pwd = run('pwd');
if($err) {
  print $err;
  exit 1;
}
chomp $pwd;
$datadir = $pwd;
if(! -d $datadir) {
  print "status: error\nMysql datadir '$datadir' in not a directory\n";
  exit 1;
}

if($snapshot or ! ($copy or $mysqldump)) {	# SNAPSHOT mode:
## assume all files in $datadir resides in single mountpoing (no symlinks)!
## remove stale snapshots
## try to make test snapshot (this also flush filesystem cache)
  if($UNAME ne 'FreeBSD') {
    print "status: error\nOnly FreeBSD snapshots are supported\n";
    exit 1;
  }
  $df = `/bin/df -kl '$datadir/'`;
  if($df !~ /^Filesystem\s+(?:1K|1024)-blocks\s+Used\s+Avail(?:able)?\s+(?:Capacity|Use%)\s+Mounted on\n\S+\s+\d+\s+\d+\s+\d+\s+\d+%\s+(\S+)/s) {
    print "status: error\n`/bin/df -kl '$datadir/'` returns '$df'\n";
    exit 1;
  }
  $mnt = $1;
  if($datadir !~ /$mnt/) {
    print "status: error\n$datadir is not found in $mnt\n";
    exit 1;
  }
  $subdir = $';

  ## delete stale snapshots
  opendir D, "$mnt/.snap";
  while($snap = readdir(D)) {
    if($snap =~ /^snap\.mb\.\d+/) {
      unlink("$mnt/.snap/$snap");
    }
  }
  closedir D;
  if(! -d "$mnt/.snap") {
    mkdir "$mnt/.snap";
    chmod 0775, "$mnt/.snap";
  }
  ## try to make test snapshot
  $ret = run("$MKSNAP_FFS '$mnt' '$mnt/.snap/snap.mb.test.$$'", $MKSNAP_TIMEOUT);
  unlink "$mnt/.snap/snap.mb.test.$$";
  if($err) {
    print $err;
    exit(1);
  }
} else {					# copy/mysqldump mode
## find databases/tables to dump
## determine its size
## find most free partition

# determines files to backup
  for $file (<*/*.frm>) {
    $file =~ /^([\w-]+)\/([a-z0-9_-]+)\.frm$/i or next;
    next if $db and $db ne $1;
    next if $table and $table ne $2;
    push @files, $file;
    push @{$lock_it{$1}->{$2}}, $file;
    if(-e "$1/$2.MYI" and -e "$1/$2.MYD") {
      push @files, "$1/$2.MYI", "$1/$2.MYD";
      push @{$lock_it{$1}->{$2}}, "$1/$2.MYI", "$1/$2.MYD";
    } elsif(-e "$1/$2.ibd") {
      push @files, "$1/$2.ibd";
      push @{$lock_it{$1}->{$2}}, "$1/$2.ibd";
    } else {
      $innodb{$1}->{$2} = undef;
    }
  }
  if((scalar keys %innodb) >= 1) {			# there are innodb tables which uses common ib* files
    for $file (<ib*>) {
      if(-f $file) {
        push @files, $file;
        push @ibfiles, $file;
      }
    }
  }
  if($#files <= 1) {
    print "status: error\nNo files to dump: @files\n";
    exit 1;
  }
  $files = join "' '", @files;            # quote files by ''
  $files = "'$files'";
## determine partition with maximum freespace
  if($UNAME eq "FreeBSD\n") {
    @df = `df -kt ufs`;
  } else {
    @df = `df -kl`;
  }
  for (@df[1 .. $#df]) {
    chomp;
    next unless /^\S+\s+\d+\s+\d+\s+(\d+)\s+\d+%\s+(\S+)$/;
    if($max_avail < $1) {
      $max_path = $2;
      $max_avail = $1;
    }
  }
  if(!$max_path) {
    print "status: error\nCan't find free partition on:\n@df\n";
    exit 1;
  }
  $max_path .= "/$BACKDIR";
## determine needed space
  for $file (@files) {
    @stat = stat("$datadir/$file");
    if($#stat != 12) {
      print "status: error\nCan't stat('$datadir/$file'): $!\n";
      exit 1;
    }
    $space += $stat[7];
  }
  $space /= 1024;         # convert to KB
  if($space + $MINFREESPACE > $max_avail) {
    print "status: error\nNot enough space: $space + $MINFREESPACE > $max_avail\n";
    exit 1;
  }
## do dirty copy (we'll sync it later)
  run("rm -rf '$max_path'") if -d $max_path;
  mkdir $max_path;
  chmod 0700, $max_path;
  if($copy) {
    $ret = run("(tar chpf - $files |tar xpf - -C '$max_path')");
    if($ret and $ret !~ /file changed as we read it/ and $ret !~ /file may have grown while being archived/) {
      print "status: error\n$ret\n";
      run("rm -rf '$max_path'");
      exit 1;
    }
  } else {				# mysqldump method, simply do it
    for $d (keys %lock_it) {
      mkdir "$max_path/$d";
      for $t (keys %{$lock_it{$d}}) {
        $ret = run("($MYSQLDUMP $d $t | gzip > '$max_path/$d/$t.sql.gz')", $MYSQLDUMP_TIMEOUT);
        if($ret) {
          print "status: error\n$ret\n";
          run("rm -rf '$max_path'");
          exit 1;
        }
      }
    } 
    print "status: mysqldump\npath: $max_path\n";
    exit 0;
  }
}

if($nolock) {				# no need in lock holding
  if($copy) {
## we try to flush all data just before syncing files per table basis
    for $d (keys %lock_it) {
      for $t (keys %{$lock_it{$d}}) {
        $f = join "' '", @{$lock_it{$d}->{$t}};
        $f = "'$f'";
        $ret = run("($MYSQLA flush-tables && rsync -aLR --inplace $f '$max_path/')");
        if($ret) {
          print "status: error\n$ret\n";
          run("rm -rf '$max_path'");
          exit 1;
        }
      }
    }
    if($#ibfiles >= 0) {
      $f = join "' '", @ibfiles;
      $f = "'$f'";
      $ret = run("($MYSQLA flush-tables && rsync -aLR --inplace $f '$max_path/')");
      if($ret) {
        print "status: error\n$ret\n";
        run("rm -rf '$max_path'");
        exit 1;
      }
    }
    print "status: copy\npath: $max_path\n";
  } else {
## snapshot mode
    $ret = run("($MYSQLA flush-tables && $MKSNAP_FFS '$mnt' '$mnt/.snap/snap.mb.$$')", $MKSNAP_TIMEOUT);
    if($ret) {
      print "status: error\n$ret\n";
      unlink("$mnt/.snap/snap.mb.$$'");
      exit 1;
    }
    mount_snapshot();
  }
  exit 0;
}

## most coplex part - backup with holding lock on tables or all db

## use here mysql 'system' feature to make snapshot/rsync exactly after flushing tables, and to unlock tables when snapshot/rsync is done
## also use wrapper $SYSTEM for feedback
if($copy) {
  $TIMEOUT = $RSYNC_TIMEOUT;
  $EXECONERR = "rm -rf '$max_path'";
  for $d (keys %lock_it) {
    $DB = $d;
    for $t (keys %{$lock_it{$d}}) {
      $f = join "' '", @{$lock_it{$d}->{$t}};
      $f = "'$f'";
      $COMMAND = "LOCK TABLE $t READ;\nFLUSH TABLE $t;\nsystem $SYSTEM $$ rsync -aRL --inplace $f '$max_path/';\nUNLOCK TABLES;\n";
      mysql_exec();
    }
  }
  if((scalar keys %innodb) => 1) {
    if((scalar keys %innodb) == 1) {
      ($DB) = keys %innodb;
      $COMMAND = "LOCK TABLE " . join(' READ, ', keys(%{$innodb{$DB}})) . ' READ;\nFLUSH TABLE ' . join(', ', keys(%{$innodb{$DB}})) .
                 ";\nsystem $SYSTEM $$ rsync -aRL --inplace $f '$max_path/';\nUNLOCK TABLES;\n";
    } else {
      $DB = 'mysql';
      $COMMAND = "FLUSH TABLES WITH READ LOCK;\nsystem $SYSTEM $$ rsync -aRL $files '$max_path/';\nUNLOCK TABLES;\n";
    }
    mysql_exec();
  }
  print "status: copy\npath: $max_path\n";
  exit 0;
}
  
### snapshot with locking all db
$COMMAND = "FLUSH TABLES WITH READ LOCK;\nsystem $SYSTEM $$ '$MKSNAP_FFS' '$mnt' '$mnt/.snap/snap.mb.$$';\nUNLOCK TABLES;\n";
$TIMEOUT = $MKSNAP_TIMEOUT;
$DB = 'mysql';
$EXECONERR = "rm -f '$mnt/.snap/snap.mb.$$'";

mysql_exec();
mount_snapshot();
exit 0;

sub mysql_exec() {
  $ok = open M, "| $MYSQL $DB";
  if(! $ok) {
    print "status: error\nopen('| $MYSQL') returns $!\n";
    exit 1;
  }
  select M;
  $| = 1;
  select STDOUT;
  $ok = print M $COMMAND;
  if(! $ok) {
    print "status: error\nerror while printing to '| mysql': $!\n";
    `$EXECONERR`;
    exit 1;
  }

  while(! -f "/tmp/system.$$") {
    select(undef,undef,undef, 0.1);
    $TIMEOUT -= 0.1;
    if(0 >= $TIMEOUT) {
      print "status: error\n$COMMAND timeouted!\n";
      `$EXECONERR`;
      exit 1;
    }
  }
  select(undef,undef,undef, 0.1);
  close M;

  ## verify exit message of snapshot command
  open S, "/tmp/system.$$";
  @ret = <S>;
  close S;
  unlink "/tmp/system.$$";
  if($ret[0] ne "DONE\n") {
    print "status: error\n$COMMAND returns: ",@ret, "\n";;
    `$EXECONERR`;
    exit 1;
  }
}

sub mount_snapshot() {
  if(! -f "$mnt/.snap/snap.mb.$$") {
    print "status: error\n`/usr/local/rcp/bin/mksnap '$mnt' $$` returns 'DONE' but file '$mnt/.snap/snap.mb.$$' does not exist!\n";
    exit 1;
  }

  ## make pseudo-device
  $ret = run("mdconfig -a -t vnode -n -o readonly -f '$mnt/.snap/snap.mb.$$'");
  if($err) {
    print "status: error\n$err\n";
    unlink "$mnt/.snap/snap.mb.$$";
    exit 1;
  }
  if($ret !~ /^(\d+)\n$/) {
    unlink "$mnt/.snap/snap.mb.$$";
    print "status: error\nCan not parse `mdconfig -a -t vnode -n -f '$mnt/.snap/snap.mb.$$'` output: $ret\n";
    exit 1;
  }
  $md = $1;

  ## mount it
  mkdir $MOUNT;
  chmod 0700, $MOUNT;
  $ret = run("mount -r /dev/md$md $MOUNT");
  if($err) {
    print "status: error\n$err\n";
    `mdconfig -d -u $md`;
    unlink "$mnt/.snap/snap.mb.$$";
    exit 1;
  }

## well done
  print "status: snapshot
snapshot: $mnt/.snap/snap.mb.$$
mdnum: $md
path: $MOUNT/$subdir
";
  exit 0;
}

sub show_tables() {
  @list = `cd '$datadir' && find . -name '*.MYD' -or -name '*.idb'`;
  if($#list < 5) {
    print "status: error\n`cd '$datadir' && find . -name '*.MYD'` returns @list\n";
    return 1;
  }
  print "status: list\nlist:";
  for $table (@list) {
    chomp $table;
    $table =~ s/^\.\///;
    $table =~ s/\.(MYD|idb)$//;
    print ' ', $table;
  }
  print "\n";
  return 0;
}

sub run {
  my $command = shift;
  my $timeout = shift;
  my $ret;
  $timeout = 0 if $timeout < 0;
  eval {
    local $SIG{ALRM} = sub { die "alarm\n" };
    alarm $timeout;
    $ret = `$command 2>&1`;
    alarm 0;
  };
  if($@) {
    $err = "status: error\n$command timeouted $timeout sec\n";
  } elsif($?) {
    $err =  "status: error\n$command exited with $?, output is $ret";
  } else {
    $err = undef;
  }
  return $ret;
}


## try to set lock
sub try_lock($) {
  my $lock = shift;
  return(0) if in_progress($lock);
  open LOCK, ">> $lock" or return(0);
  print LOCK "$$\n";
  close LOCK;
  open LOCK, $lock or return(0);        # are we first ?
  my $pid = <LOCK>;
  chomp $pid;
  close LOCK;
  if($pid == $$) {
    $LOCKED = 1;
  }
  return $LOCKED;
}

## check for lock, if found - check is it actual or no
sub in_progress($) {
  my $lock = shift;
  if(-f $lock) {
    open(LOCK, $lock) or return(1);
    my $pid = <LOCK>;
    chomp $pid;
    close LOCK;
    if($pid !~ /^\d+$/) {	# manually locked ?
      return(1);
    }
    if(kill(0, $pid)) {
      return(1);
    }
    if(! -f $lock) {
      return(1);
    }
    unlink($lock);		# stale lock file
  }
  return(0);
}

## just remove lock
sub END {
  unlink($LOCKFILE) if $LOCKED;
}

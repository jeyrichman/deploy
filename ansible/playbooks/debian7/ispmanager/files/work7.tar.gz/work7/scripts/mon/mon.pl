#!/usr/bin/perl -ws

# modules
use strict;
use FindBin qw($Bin);
use vars qw($stop $daemon $v);
use lib "$Bin/lib/$^O"; 
use Module;

# environment variables
$ENV{'PATH'} = '/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin:/usr/X11R6/bin';
$ENV{'BLOCKSIZE'} = 'K';

$0='/usr/bin/perl -ws '.$0;

my $os_type = $^O;
my $os_release = `sysctl -n kernel.osrelease 2>/dev/null` . `sysctl -n kern.osrelease 2>/dev/null`;
chomp($os_release = lc($os_release));
my ($module_v, $os_branch);
$module_v = $Module::VERSION;
if ($os_type eq 'freebsd') {
  $os_release = (split(/\-/, $os_release))[0];
  $os_release = $1 if ($os_release =~ m#^(\d+\.\d+)#);
  $os_branch = $os_release;
  $os_branch =~ s#\..*$##;
} elsif ($os_type eq 'linux') {
  $os_branch = 'all';
} else {
  die "OS is not supported.";
}

# variables
my $VERSION='0.0.1';
my $host = '127.0.0.1';
my $base_dir = "$Bin";
my $rrd_path = "$base_dir/rrdtool/rrd/$host";
my $main_prog = "$base_dir/mon.pl";
my $conf_file = "$base_dir/conf/mon.conf.$os_type";
my $add_conf_file = "$conf_file-$os_branch";
my $main_module = "$base_dir/lib/$^O/Module.pm";
my $first_main_prog_mtime = (stat $main_prog)[9];
my $first_conf_file_mtime = (stat $conf_file)[9];
my $first_add_conf_file_mtime = (stat $add_conf_file)[9];
my $first_main_module_mtime = (stat $main_module)[9];
my %monthes = (
  'Jan' => '01',
  'Feb' => '02',
  'Mar' => '03',
  'Apr' => '04',
  'May' => '05',
  'Jun' => '06',
  'Jul' => '07',
  'Aug' => '08',
  'Sep' => '09',
  'Oct' => '10',
  'Nov' => '11',
  'Dec' => '12'
);

# signals
$SIG{'HUP'} = sub { $main_conf{'mon_all'} = $main_conf{'mon_all'} ? 0 : 1;
if ($main_conf{'mon_all'}){$0=~s/ \[stop\]//;} else {$0=~s/$/ [stop]/;};};

$SIG{'ALRM'} = sub {
  return unless ($main_conf{'mon_alive'});
  my $email = $action2email{'alive'};
  return unless ($main_conf{'mon_alive_period'});
  my $body = time;
  my $subject = 'SysMon :: Monitoring is alive';
  foreach (split /,/, $email) {
    next if (!length($_));
    open MAIL, "|$main_conf{'mail'} -s '$subject' $_";
    print MAIL "$body\n";
    close MAIL;
  }
  alarm($main_conf{'mon_alive_period'});
};
					
# procedures and functions

# load configs
die if (!load_conf($conf_file, 1));
load_conf($add_conf_file, 0);

$main_conf{'daemon'} = $daemon;
$main_conf{'stop'} = $stop;

# main part
if ($v) {
  print "KS monitoring system v. $VERSION\n";
  print "Module v. $module_v\n";
  exit(0);
}

init($action2email{'init'});

my (@ps, $top, $time2sleep, $mon_cycles);
$mon_cycles = 0;
alarm(int(rand($main_conf{'mon_alive_period'})));

if ($os_type eq 'freebsd') {
  do {
    if ($os_branch == 4) {
      @ps = `ps -axwwwo user,pid,rss,pcpu,state,time,cputime,command`;
    } else {
      @ps = `ps -axwwwo user,pid,rss,pcpu,state,etime,cputime,command`;
    }
    shift(@ps);
    chomp(@ps);
    $top = `top -q -u -s1 -d2 0`;
    &restart($main_prog, $main_prog, $first_main_prog_mtime);
    &restart($main_prog, $main_module, $first_main_module_mtime);
    &restart($main_prog, $conf_file, $first_conf_file_mtime);
    &restart($main_prog, $add_conf_file, $first_add_conf_file_mtime);
    if ($main_conf{mon_all} == 1) {
      mon_net_if($action2email{'net_if'}, $mon_cycles);
      mon_disk_usage($action2email{'disk_usage'});
      mon_mbuf_clusters_usage($action2email{'mbuf'}, $os_release);
      mon_sysctl_usage($action2email{'sysctl'});
      mon_temperature($action2email{'temperature'}, $os_release);
      mon_raid_health($action2email{'raid'}, $mon_cycles);
      mon_hdd_overload($action2email{'hdd_overload'}, $mon_cycles, "$rrd_path/res_usage/disk_activity.rrd");
      mon_cpu_overload($action2email{'cpu_overload'}, $mon_cycles, "$rrd_path/cpu_usage.rrd");
      mon_swap_usage($action2email{'swap_usage'}, $top, @ps);
      mon_la($action2email{'la'}, $top);
      mon_zombie_count($action2email{'zombie_count'}, @ps);
      mon_socket_overload($action2email{'socket_overload'});
      mon_apache_max_clients($action2email{'apache_max_clients'}, %monthes);
      mon_ps($action2email{'ps'}, $os_branch, @ps);
      mon_mysql($action2email{'mysql'}, $top, @ps);
      mon_kmem_usage($action2email{'kmem_usage'}, $os_branch);
      mon_apache_page($action2email{'apache_page'}, $mon_cycles);
    }
    $mon_cycles++;
    $time2sleep = 60 - (time() - $main_conf{'start_time'}) % 60;
    exit(0) unless ($main_conf{'daemon'});
  } while (sleep($time2sleep));
} elsif ($os_type eq 'linux') {
  do {
    @ps = `ps axwwwo user,pid,rss,pcpu,state,etime,cputime,command`;
    shift(@ps);
    chomp(@ps);
    my @top = split(m#\n#, `top -b -d 1 -n 2 -p 100000`);
    $top = join("\n", @top[9..$#top - 2]);
    &restart($main_prog, $main_prog, $first_main_prog_mtime);
    &restart($main_prog, $main_module, $first_main_module_mtime);
    &restart($main_prog, $conf_file, $first_conf_file_mtime);
    &restart($main_prog, $add_conf_file, $first_add_conf_file_mtime);
    if ($main_conf{mon_all} == 1) {
      mon_net_if($action2email{'net_if'}, $mon_cycles);
      mon_disk_usage($action2email{'disk_usage'});
      mon_sysctl_usage($action2email{'sysctl'});
      mon_cpu_overload($action2email{'cpu_overload'}, $mon_cycles, "$rrd_path/cpu_usage.rrd");
      mon_swap_usage($action2email{'swap_usage'}, $top, @ps);
      mon_la($action2email{'la'}, $top);
      mon_zombie_count($action2email{'zombie_count'}, @ps);
      mon_apache_max_clients($action2email{'apache_max_clients'}, %monthes);
      mon_ps($action2email{'ps'}, @ps);
      mon_mysql($action2email{'mysql'}, $top, @ps);
      mon_apache_page($action2email{'apache_page'}, $mon_cycles);
    }
    $mon_cycles++;
    $time2sleep = 60 - (time() - $main_conf{'start_time'}) % 60;
    exit(0) unless ($main_conf{'daemon'});
  } while (sleep($time2sleep));
}
# end of main part

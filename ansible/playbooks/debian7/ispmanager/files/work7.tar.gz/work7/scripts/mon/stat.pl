#!/usr/bin/perl -ws

# modules
use strict;
use FindBin qw($Bin);
use vars qw($stop $daemon $v);
use lib "$Bin/lib/$^O";
use Module;

# environment variables
$ENV{'PATH'} = '/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin:/usr/X11R6/bin';
$ENV{'BLOCKSIZE'} = 'K';

my $os_type = $^O;
my $os_release = `sysctl -n kernel.osrelease 2>/dev/null` . `sysctl -n kern.osrelease 2>/dev/null`;
chomp($os_release = lc($os_release));
my ($module_v, $os_branch);
$module_v = $Module::VERSION;
if ($os_type eq 'freebsd') {
  $os_release = (split(/\-/, $os_release))[0];
  $os_release = $1 if ($os_release =~ m#^(\d+\.\d+)#);
  $os_branch = $os_release;
  $os_branch =~ s#\..*$##;
} elsif ($os_type eq 'linux') {
  $os_branch = 'all';
} else {
  die "OS is not supported.";
}

# common config options

# variables
my $VERSION='0.0.1';
my $host = '127.0.0.1';
my $base_dir = "$Bin";
my $main_prog = "$base_dir/stat.pl";
my $rrd_path = "$base_dir/rrdtool/rrd/$host";
my $conf_file = "$base_dir/conf/mon.conf.$os_type";
my $add_conf_file = "$conf_file-$os_branch";
my $net_speed = '100M';
my $maxo = 13107200;

# procedures and functions

# load configs
die if (!load_conf($conf_file, 1));
load_conf($add_conf_file, 0);

# main part
if ($v) {
  print "AH statistics system v. $VERSION\n";
  print "Module v. $module_v\n";
  exit(0);
}

my ($data_ref, %data, @ps, $top);

if ($os_type eq 'freebsd') {
  if ($os_branch == 4) {
    @ps = `ps -axwwwo user,pid,rss,pcpu,state,time,cputime,command`;
  } else {
    @ps = `ps -axwwwo user,pid,rss,pcpu,state,etime,cputime,command`;
  }
  shift(@ps);
  chomp(@ps);
  $top = `top -q -u -s1 -d2 0`;

  # Network Interfaces
  foreach my $if (split(/\s+/, `ifconfig -l -u`)) {
    $data_ref = get_net_if_traffic($if);
    if ($os_type eq 'freebsd') {
        $net_speed = `ifconfig $if|grep media|awk '{print \$4}'|tail -c +2|awk -F'b' '{print \$1 "M"}'`;}
    else {
        $net_speed = `ethtool $if|grep Speed|awk '{print \$2}'|awk -F 'b' '{print \$1}'`;}

    if ($net_speed =~ /M/) {
        $maxo = (split(/M/,$net_speed))[0]*1024*1024/8;
    }
    elsif ($net_speed =~ /G/) {
        $maxo = (split(/G/,$net_speed))[0]*1024*1024*1024/8;
    }
    else {
        $maxo = 10*1024*1024*1024/8; }

    if (!-e "$rrd_path/net_if/$if.rrd") {
      `rrdtool create $rrd_path/net_if/$if.rrd --start N --step 60 \\
         DS:traf_in:DERIVE:120:0:$maxo \\
         DS:traf_out:DERIVE:120:0:$maxo \\
         RRA:AVERAGE:0.5:1:864 \\
         RRA:AVERAGE:0.5:5:864 \\
         RRA:AVERAGE:0.5:60:864 \\
         RRA:AVERAGE:0.5:720:864 \\
         RRA:AVERAGE:0.5:2880:864
      `;
    }
    update_rrd_data("$rrd_path/net_if/$if.rrd", $data_ref -> {'traf_in'}, $data_ref -> {'traf_out'});
  }

  # CPU Usage
  $data_ref = get_cpu_usage($top);
  update_rrd_data("$rrd_path/cpu_usage.rrd", $data_ref -> {'cpu_idle'}, $data_ref -> {'cpu_sys'}, 
    $data_ref -> {'cpu_user'}, $data_ref -> {'cpu_nice'}, $data_ref -> {'cpu_interrupt'} );

  # Resource Usage Per User
  $data_ref = get_user_activity(@ps);
  %data = %${data_ref};
  foreach(keys(%data)) {
    my ($user, $cpu, $memory, $ps_count) = ($_, split(/:/, $data{$_}, 3));
    if (!-e "$rrd_path/users/$user.rrd") {
      `rrdtool create $rrd_path/users/$user.rrd --start N --step 60 \\
        DS:cpu:GAUGE:120:U:U \\
        DS:memory:GAUGE:120:U:U \\
        DS:ps_count:GAUGE:120:U:U \\
        RRA:AVERAGE:0.5:1:864 \\
        RRA:AVERAGE:0.5:5:864 \\
        RRA:AVERAGE:0.5:60:864 \\
        RRA:AVERAGE:0.5:720:864 \\
        RRA:AVERAGE:0.5:2880:864
      `;
    }
    update_rrd_data("$rrd_path/users/$user.rrd", $cpu, $memory, $ps_count);
  }
  undef(%data);

  # Load Average
  $data_ref = &get_la($top);
  update_rrd_data("$rrd_path/la.rrd", $data_ref -> {'la_1'}, $data_ref -> {'la_5'}, $data_ref -> {'la_15'} );

  # Resources Usage + HDD Stats
  $data_ref = get_hdd_stats($os_release);
  update_rrd_data("$rrd_path/hdd_load.rrd", $data_ref->{'hdd_rs'}, 
    $data_ref->{'hdd_mrs'}, $data_ref->{'hdd_ws'}, $data_ref->{'hdd_mws'});
  update_rrd_data("$rrd_path/res_usage/disk_activity.rrd", $data_ref -> {'hdd_gstat_load'});
  $data_ref = get_mbuf_clusters_usage($os_release);
  update_rrd_data("$rrd_path/res_usage/mbuf_clusters.rrd", $data_ref -> {'mbuf_clusters_usage'});
  $data_ref = get_sysctl_usage($os_branch);
  update_rrd_data("$rrd_path/res_usage/kmem_usage.rrd", $data_ref -> {'kmem_usage'});
  update_rrd_data("$rrd_path/res_usage/kmem_pv_entry.rrd", $data_ref -> {'kmem_pv_entry'});
  foreach (keys(%sysctl_conf)) {
    my $rrd = $_;
    $rrd =~ s#^.+\|##;
    my $key = $rrd;
    $rrd =~ s#\.#_#g;
    if (!-e "$rrd_path/res_usage/$rrd.rrd" ) {
      `rrdtool create $rrd_path/res_usage/$rrd.rrd --start N --step 60  \\
        DS:usage:GAUGE:120:U:U \\
        RRA:AVERAGE:0.5:1:864 \\
        RRA:AVERAGE:0.5:5:864 \\
        RRA:AVERAGE:0.5:60:864 \\
        RRA:AVERAGE:0.5:720:864 \\
        RRA:AVERAGE:0.5:2880:864
      `;
    }
    update_rrd_data("$rrd_path/res_usage/$rrd.rrd", $data_ref -> {$key});
  }
  
  # MySQL Stats
  $data_ref = get_mysql_stats();
  update_rrd_data("$rrd_path/mysql.rrd", $data_ref->{'mysql_questions'}, 
    $data_ref->{'mysql_threads'}, $data_ref->{'mysql_slow_queries'}) if (defined($data_ref));

  # Memory Usage
  $data_ref = get_mem_usage($top);
  update_rrd_data("$rrd_path/mem_usage.rrd", $data_ref -> {'mem_active'}, 
    $data_ref -> {'mem_inactive'}, $data_ref -> {'mem_wired'}, $data_ref -> {'mem_cache'}, 
    $data_ref -> {'mem_buf'}, $data_ref -> {'mem_free'}, $data_ref -> {'mem_swap'});

  # Process Count
  $data_ref = get_ps_count(@ps);
  update_rrd_data("$rrd_path/ps_count/other.rrd", $data_ref -> {'pc_other'});
  update_rrd_data("$rrd_path/ps_count/zombie.rrd", $data_ref -> {'pc_zombie'});
  foreach (@count_ps_conf) {
    my @paths = split(m#/#, $_);
    my $rrd = $paths[$#paths];
    if (!-e "$rrd_path/ps_count/$rrd.rrd" ) {
      `rrdtool create $rrd_path/ps_count/$rrd.rrd --start N --step 60  \\
        DS:count:GAUGE:120:U:U \\
        RRA:AVERAGE:0.5:1:864 \\
        RRA:AVERAGE:0.5:5:864 \\
        RRA:AVERAGE:0.5:60:864 \\
        RRA:AVERAGE:0.5:720:864 \\
        RRA:AVERAGE:0.5:2880:864
      `;
    }
    update_rrd_data("$rrd_path/ps_count/$rrd.rrd", $data_ref -> {"pc_$_"});
  }

  # Process Size
  $data_ref = get_ps_size(@ps);
  update_rrd_data("$rrd_path/ps_size.rrd", $data_ref -> {'max_httpd'}, 
    $data_ref -> {'max_mysqld'}, $data_ref -> {'first_max_ps'}, $data_ref -> {'second_max_ps'});

  # Disk Usage[space + inodes]
  $data_ref = get_disk_usage();
  my @d_u_current = `df -t ufs,zfs`;
  shift(@d_u_current);
  chomp(@d_u_current);
  foreach (@d_u_current) {
    my $mount_point = (split(/\s+/, $_, 6))[5];
    next if ($mount_point eq '/.mysqlbackup');
    my $rrd = $mount_point;
    $rrd =~ s#/#_#g;
    if (!-e "$rrd_path/disk_usage/$rrd.rrd") {
      `rrdtool create $rrd_path/disk_usage/$rrd.rrd --start N --step 60  \\
        DS:space:GAUGE:120:U:U \\
        DS:inodes:GAUGE:120:U:U \\
        RRA:AVERAGE:0.5:1:864 \\
        RRA:AVERAGE:0.5:5:864 \\
        RRA:AVERAGE:0.5:60:864 \\
        RRA:AVERAGE:0.5:720:864 \\
        RRA:AVERAGE:0.5:2880:864
      `;
    }
    update_rrd_data("$rrd_path/disk_usage/$rrd.rrd", $data_ref->{"space_$mount_point"}, $data_ref->{"inodes_$mount_point"});
  }

  # Temperature[mbmon + sysctl]
  $data_ref = get_temperature($os_release);
  update_rrd_data("$rrd_path/temperature.rrd", 
    $data_ref->{'temperature_mbmon_box'}, $data_ref->{'temperature_mbmon_processor'}, 
    $data_ref->{'temperature_min_core'}, $data_ref->{'temperature_max_core'});
} elsif ($os_type eq 'linux') {
  @ps = `ps axwwwo user,pid,rss,pcpu,state,etime,cputime,command`;
  shift(@ps);
  chomp(@ps);
  my @top = split(m#\n#, `top -b -d 1 -n 2 -p 100000`);
  $top = join("\n", @top[8..$#top - 2]);

  # Network Interfaces
  foreach my $if (grep(m#^\d+:\s+\w+:\s+<.*>#, `ip link show up`)) {
    $if = $1 if ($if =~ m#^\d+:\s+(\w+):\s+<.*>#);
    $data_ref = get_net_if_traffic($if);
    if ($os_type eq 'freebsd') {
        $net_speed = `ifconfig $if|grep media|awk '{print \$4}'|tail -c +2|awk -F'b' '{print \$1 "M"}'`;}
    else {
        $net_speed = `ethtool $if|grep Speed|awk '{print \$2}'|awk -F 'b' '{print \$1}'`;}

    if ($net_speed =~ /M/) {
        $maxo = (split(/M/,$net_speed))[0]*1024*1024/8;
    }
    elsif ($net_speed =~ /G/) {
        $maxo = (split(/G/,$net_speed))[0]*1024*1024*1024/8;
    }
    else {
        $maxo = 10*1024*1024*1024/8; }

    if (!-e "$rrd_path/net_if/$if.rrd") {
      `rrdtool create $rrd_path/net_if/$if.rrd --start N --step 60 \\
         DS:traf_in:DERIVE:120:0:$maxo \\
         DS:traf_out:DERIVE:120:0:$maxo \\
         RRA:AVERAGE:0.5:1:864 \\
         RRA:AVERAGE:0.5:5:864 \\
         RRA:AVERAGE:0.5:60:864 \\
         RRA:AVERAGE:0.5:720:864 \\
         RRA:AVERAGE:0.5:2880:864
      `;
    }
    update_rrd_data("$rrd_path/net_if/$if.rrd", $data_ref -> {'traf_in'}, $data_ref -> {'traf_out'});
  }

  # CPU Usage
  $data_ref = get_cpu_usage($top);
  update_rrd_data("$rrd_path/cpu_usage.rrd", $data_ref -> {'cpu_user'}, $data_ref -> {'cpu_sys'}, 
    $data_ref -> {'cpu_nice'}, $data_ref -> {'cpu_idle'}, $data_ref -> {'cpu_iowait'}, 
    $data_ref -> {'cpu_hi'}, $data_ref -> {'cpu_si'}, $data_ref -> {'cpu_st'});

  # Resource Usage Per User
  $data_ref = get_user_activity(@ps);
  %data = %${data_ref};
  foreach(keys(%data)) {
    my ($user, $cpu, $memory, $ps_count) = ($_, split(/:/, $data{$_}, 3));
    if (!-e "$rrd_path/users/$user.rrd") {
      `rrdtool create $rrd_path/users/$user.rrd --start N --step 60 \\
        DS:cpu:GAUGE:120:U:U \\
        DS:memory:GAUGE:120:U:U \\
        DS:ps_count:GAUGE:120:U:U \\
        RRA:AVERAGE:0.5:1:864 \\
        RRA:AVERAGE:0.5:5:864 \\
        RRA:AVERAGE:0.5:60:864 \\
        RRA:AVERAGE:0.5:720:864 \\
        RRA:AVERAGE:0.5:2880:864
      `;
    }
    update_rrd_data("$rrd_path/users/$user.rrd", $cpu, $memory, $ps_count);
  }
  undef(%data);

  # Load Average
  $data_ref = &get_la($top);
  update_rrd_data("$rrd_path/la.rrd", $data_ref -> {'la_1'}, $data_ref -> {'la_5'}, $data_ref -> {'la_15'} );

  # Resources Usage + HDD Stats
  $data_ref = get_hdd_stats();
  update_rrd_data("$rrd_path/hdd_load.rrd", $data_ref->{'hdd_rs'}, 
    $data_ref->{'hdd_mrs'}, $data_ref->{'hdd_ws'}, $data_ref->{'hdd_mws'});
  $data_ref = get_sysctl_usage();
  foreach (keys(%sysctl_conf)) {
    my $rrd = $_;
    $rrd =~ s#^.+\|##;
    my $key = $rrd;
    $rrd =~ s#\.#_#g;
    if (!-e "$rrd_path/res_usage/$rrd.rrd" ) {
      `rrdtool create $rrd_path/res_usage/$rrd.rrd --start N --step 60  \\
        DS:usage:GAUGE:120:U:U \\
        RRA:AVERAGE:0.5:1:864 \\
        RRA:AVERAGE:0.5:5:864 \\
        RRA:AVERAGE:0.5:60:864 \\
        RRA:AVERAGE:0.5:720:864 \\
        RRA:AVERAGE:0.5:2880:864
      `;
    }
    update_rrd_data("$rrd_path/res_usage/$rrd.rrd", $data_ref -> {$key});
  }
  
  # MySQL Stats
  $data_ref = get_mysql_stats();
  update_rrd_data("$rrd_path/mysql.rrd", $data_ref -> {'mysql_questions'}, 
    $data_ref -> {'mysql_threads'}, $data_ref -> {'mysql_slow_queries'}) if (defined($data_ref));

  # Memory Usage
  $data_ref = get_mem_usage($top);
  update_rrd_data("$rrd_path/mem_usage.rrd", $data_ref -> {'mem_total'}, 
    $data_ref -> {'mem_used'}, $data_ref -> {'mem_free'}, $data_ref -> {'mem_buffers'}, 
    $data_ref -> {'mem_swap'});

  # Process Count
  $data_ref = get_ps_count(@ps);
  update_rrd_data("$rrd_path/ps_count/other.rrd", $data_ref -> {'pc_other'});
  update_rrd_data("$rrd_path/ps_count/zombie.rrd", $data_ref -> {'pc_zombie'});
  foreach (@count_ps_conf) {
    my @paths = split(m#/#, $_);
    my $rrd = $paths[$#paths];
    if (!-e "$rrd_path/ps_count/$rrd.rrd" ) {
      `rrdtool create $rrd_path/ps_count/$rrd.rrd --start N --step 60  \\
        DS:count:GAUGE:120:U:U \\
        RRA:AVERAGE:0.5:1:864 \\
        RRA:AVERAGE:0.5:5:864 \\
        RRA:AVERAGE:0.5:60:864 \\
        RRA:AVERAGE:0.5:720:864 \\
        RRA:AVERAGE:0.5:2880:864
      `;
    }
    update_rrd_data("$rrd_path/ps_count/$rrd.rrd", $data_ref -> {"pc_$_"});
  }

  # Process Size
  $data_ref = get_ps_size(@ps);
  update_rrd_data("$rrd_path/ps_size.rrd", $data_ref -> {'max_httpd'}, 
    $data_ref -> {'max_mysqld'}, $data_ref -> {'first_max_ps'}, $data_ref -> {'second_max_ps'});

  # Disk Usage[space + inodes]
  $data_ref = get_disk_usage();
  my @d_u_current = `df -k -t ext2 -t ext3 -t ext4 -t reiserfs -t xfs`;
  shift(@d_u_current);
  chomp(@d_u_current);
  foreach (@d_u_current) {
    my $mount_point = (split(/\s+/, $_, 6))[5];
    next if ($mount_point eq '/.mysqlbackup');
    my $rrd = $mount_point;
    $rrd =~ s#/#_#g;
    if (!-e "$rrd_path/disk_usage/$rrd.rrd") {
      `rrdtool create $rrd_path/disk_usage/$rrd.rrd --start N --step 60  \\
        DS:space:GAUGE:120:U:U \\
        DS:inodes:GAUGE:120:U:U \\
        RRA:AVERAGE:0.5:1:864 \\
        RRA:AVERAGE:0.5:5:864 \\
        RRA:AVERAGE:0.5:60:864 \\
        RRA:AVERAGE:0.5:720:864 \\
        RRA:AVERAGE:0.5:2880:864
      `;
    }
    update_rrd_data("$rrd_path/disk_usage/$rrd.rrd", $data_ref -> {"space_$mount_point"}, $data_ref -> {"inodes_$mount_point"});
  }
}
# end of main part

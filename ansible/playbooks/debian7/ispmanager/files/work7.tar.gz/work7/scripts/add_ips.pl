#!/usr/bin/perl -s

$notest = 0 unless $notest;
$dev = 'eth0' unless $dev;
$n = 0 unless $n;

while($ips = shift) {
        if ( $ips =~ /^(\d+)\.(\d+)\.(\d+)\.(\d+)\-(\d+)$/)
        {
                ($ip1, $ip2, $ip3, $ip1s, $ip2s) = ($1, $2, $3, $4, $5);
                next unless ($ip1<=255 && $ip2<=255 && $ip3<=255 && $ip1s<=255 && $ip2s<=255);
                for(; $ip1s <= $ip2s; $ip1s++) {
                        $str .= "echo DEVICE=${dev}:${n} > /etc/sysconfig/network-scripts/ifcfg-${dev}:${n} \n";
                        $str .= "echo ONBOOT=yes >> /etc/sysconfig/network-scripts/ifcfg-${dev}:${n} \n";
                        $str .= "echo BOOTPROTO=static >> /etc/sysconfig/network-scripts/ifcfg-${dev}:${n} \n";
                        $str .= "echo IPADDR=$ip1.$ip2.$ip3.$ip1s >> /etc/sysconfig/network-scripts/ifcfg-${dev}:${n} \n";
                        $str .= "echo NETMASK=255.255.255.255 >> /etc/sysconfig/network-scripts/ifcfg-${dev}:${n} \n";
                        $n++;
                }
        }elsif ( $ips =~ /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/ ) {
                next unless ($1<=255 && $2<=255 && $3<=255 && $4<=255);
                $str .= "echo DEVICE=${dev}:${n} > /etc/sysconfig/network-scripts/ifcfg-${dev}:${n} \n";
                $str .= "echo ONBOOT=yes >> /etc/sysconfig/network-scripts/ifcfg-${dev}:${n} \n";
                $str .= "echo BOOTPROTO=static >> /etc/sysconfig/network-scripts/ifcfg-${dev}:${n} \n";
                $str .= "echo IPADDR=$1.$2.$3.$4 >> /etc/sysconfig/network-scripts/ifcfg-${dev}:${n} \n";
                $str .= "echo NETMASK=255.255.255.255 >> /etc/sysconfig/network-scripts/ifcfg-${dev}:${n} \n";
                $n++;
        }
}
$str .= "/etc/init.d/network restart \n";
system("$str") if $notest;
print $str unless $notest;

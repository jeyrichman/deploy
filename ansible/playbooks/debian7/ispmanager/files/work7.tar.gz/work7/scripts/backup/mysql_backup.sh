#!/bin/sh

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin

b_dir="/home/backup/mysql";

if [ `ls -1 $b_dir | wc -l` -gt 14 ];
then
        rm -rf $b_dir/`ls -1 $b_dir | head -1`;
fi

new_dir=`date '+%F_%T'`;
mkdir -p $b_dir/$new_dir;

/usr/work/scripts/backup/mysql_backup.pl -mysqldump || ( echo `date` | mail -s 'mysqlbackup error' notify@notify.king-support.com ); 

BAK_ROOT=`df -kl|tail -n +2| sort -k 4 -rn | head -n 1|awk '{print \$6}'`
mv -f ${BAK_ROOT}/.mysqlbackup/* $b_dir/$new_dir;
rm -rf ${BAK_ROOT}/.mysqlbackup/*

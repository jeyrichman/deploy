#!/bin/sh

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin

b_dir="/home/backup/cron/";

if [ `ls -1 $b_dir | wc -l` -eq 7 ];
then
        rm -rf $b_dir/`ls -1 $b_dir | head -1`;
fi

new_dir=`date '+%F_%T'`;
mkdir -p $b_dir/$new_dir;

if [ -e /var/spool/cron/ ]; then
    CRON_DIR='/var/spool/cron/';
elif [ -e /var/cron/tabs/ ]; then
    CRON_DIR='/var/cron/tabs/';
else
    echo 'no crontab found!';
    echo `date` | mail -s 'cronbackup error' notify@notify.king-support.com;
    exit 1;
fi
    
rsync -aHv ${CRON_DIR} $b_dir/$new_dir/


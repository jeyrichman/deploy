package Module;

use Socket;
use Sys::Syslog qw(:DEFAULT setlogsock);
use strict;

our @ISA = qw(Exporter);
our @EXPORT = qw (
  %main_conf
  %email
  %action2email
  %sysctl_conf
  %dyn_apache_conf
  %apache_logs_conf
  %run_ps_conf
  %mem_ps_conf
  %mysql_ps_conf
  @count_ps_conf
  @not_mon_fs_conf
  &load_conf
  &update_rrd_data
  &init
  &restart
  &mon_disk_usage
  &mon_sysctl_usage
  &mon_zombie_count
  &mon_apache_max_clients
  &mon_mysql
  &mon_ps
  &mon_net_if
  &mon_alive
  &mon_la
  &mon_swap_usage
  &mon_cpu_overload
  &mon_apache_page
  &last_mon_apache_page
  &get_cpu_usage
  &get_mem_usage
  &get_la
  &get_net_if_traffic
  &get_hdd_stats
  &get_sysctl_usage
  &get_ps_count
  &get_mysql_stats
  &get_disk_usage
  &get_ps_size
  &get_user_activity
);
our $VERSION='0.0.1';

# config options
our %main_conf = (
  'mail' => 'mail', # /usr/bin/mail
  'start_time' => 45,
  'mon_net_if_period' => 3600,  # seconds
  'mon_alive_period' => 3600,   # seconds
  'disk_space_max_usage' => 95, # %
  'disk_space_usage_increment' => 1, # %
  'disk_space_min_rest' => 100, # megabytes
  'disk_space_mon_min_rest' => 5120, # megabytes
  'disk_inodes_max_usage' => 70, # %
  'disk_inodes_usage_increment' => 10, # %
  'sysctl_max_usage' => 95, # %
  'sysctl_usage_increment' => 1, # %
  'swap_max_usage' => 300, # megabytes
  'swap_usage_increment' => 20, # megabytes
  'memory_min_usage' => 200, # megabytes
  'apache_max_memory_size' => 7, # megabytes
  'la_max' => 30,
  'la_increment' => 10,
  'zc_max' => 100, # zombie max count
  'zc_increment' => 50, # zombie count increment
  'ps_load_max' => 80,
  'pc_max' => 2000,
  'cputime_max' => 300, # seconds
  'cpu_mul_renice' => 30, # %
  'cpu_mul_restart' => 30, # %
  'idle_min' => 10,
  'renice_value' => 10,
  'mon_cpu_overload_period' => 3600, # seconds
  'min_cpu_overload_idle' => 50,
  'max_cpu_overload_sys_interrupt' => 20,
  'max_cpu_overload_iowait' => 50,
  'mon_all' => 1,
  'mon_swap_usage' => 1,
  'mon_ps_zombie' => 1, 
  'mon_overload_ps' => 1, # грузящие процессы
  'mon_cpu_overload' => 0,
  'mon_run_ps' => 1,   # запущенные процессы
  'mon_ps_count' => 1,
  'mon_la' => 1, 
  'mon_zombie_count' => 1, 
  'mon_mysql' => 1, 
  'mon_apache_maxclients' => 1,
  'mon_disk_usage' => 1,
  'mon_sysctl_usage' => 1,
  'mon_alive' => 0,
  'mon_net_if' => 1,
  'apache_conf_path' => '/etc/httpd/conf/vhosts-default/',
  'mon_apache_page' => 1,
  'mon_apache_page_period' => 300,  # seconds
  'mon_apache_page_nonempty' => 1,
  'mon_apache_enabled' => 1,
);

our %email = (
  1 => 'notify@notify.king-support.com'
);

our %action2email = (
  'init' => $email{1},
  'net_if' => $email{1},
  'disk_usage' => $email{1},
  'sysctl' => $email{1},
  'cpu_overload' => $email{1},
  'swap_usage' => $email{1},
  'la' => $email{1},
  'zombie_count' => $email{1},
  'apache_max_clients' => $email{1},
  'mysql' => $email{1},
  'alive' => $email{1},
  'ps' => $email{1},
  'apache_page' => $email{1},
);

our %sysctl_conf = (
  'fs.file-nr' => 'fs.file-max',
  'net.netfilter.nf_conntrack_count' => 'net.netfilter.nf_conntrack_max'
);

our @count_ps_conf = qw(
  /usr/sbin/crond
  /usr/sbin/sshd 
  /usr/sbin/syslogd 
  /usr/libexec/mysqld 
  /usr/sbin/httpd
);

our %dyn_apache_conf = (
  'root|/usr/sbin/httpd' => 'service httpd stop; sleep 3|service httpd start; sleep 3'
);

our %apache_logs_conf = (
  '/usr/sbin/httpd' => '/var/log/httpd/error_log'
);

our %run_ps_conf = (
  'root|/usr/sbin/crond' => 'service crond restart; sleep 3',
  'mysql|/usr/libexec/mysqld' => 'service mariadb restart; sleep 3',
  'exim|/usr/sbin/exim' => 'service exim restart; sleep 3',
  'root|/usr/sbin/dovecot' => 'service dovecot restart; sleep 3',
  'root|/usr/sbin/httpd' => 'service httpd restart; sleep 3',
  'root|/usr/sbin/nginx' => 'service nginx restart; sleep 3',
);

our %mem_ps_conf = (
  '/usr/libexec/mysqld' => '1:service mariadb stop; sleep 3; service mariadb start; sleep 3',
  '/usr/sbin/httpd' => '2:restart_dyn_apaches'
);

our %mysql_ps_conf = (
  '/usr/libexec/mysqld|/var/lib/mysql/mysql.sock' => 'ervice mariadb top; sleep 3; service mariadb start; sleep 3'
);

our @not_mon_fs_conf;

my %prev_values;

my %no_alarm;

my %load_ps;

my @mailservers = qw(
  162.244.33.240
  162.244.32.2
);

# procedures && functions
sub data_to_mb($) {
  my $data = shift;
  $data = int(1000 * $data / 1024) / 1000 if ($data =~ s/K$//i);
  $data =~ s/M$//i;
  return $data;
}

sub check_limit_usage($$$$) {
  my ($current, $key, $limit, $increment) = @_;
  if ($current >= $limit && !exists($prev_values{"$key"})) {
    $prev_values{"$key"} = $current;
    return 1;
  } elsif (exists($prev_values{"$key"}) && $current - $prev_values{"$key"} >= $increment) {
    $prev_values{"$key"} = $current;
    return 1;
  } elsif ($current < $limit && exists($prev_values{"$key"})) {
    delete($prev_values{"$key"});
  } 
  return 0;
}

sub load_conf($$) {
  my ($conf_file, $warn) = @_;
  eval {
    require $conf_file;
  };
  if ($@) {
    print "Loading $conf_file:\n$@" if ($warn);
    return 0;
  } else {
    return 1;
  }
}

sub get_rrd_data($$$) { # rrdres = 60 | 300 | 3600 | 43200 | 172800 only! 
  my ($rrd, $function, $rrdres) = @_;
  my @rrddata = `rrdtool fetch $rrd $function -r $rrdres -e @{[int(time()/$rrdres)*$rrdres]} -s e-$rrdres`;
  chomp(@rrddata);
  pop(@rrddata);
  my $names = shift(@rrddata);
  $names =~ s#^\s+##;
  $names =~ s#\s+$##;
  my $values = pop(@rrddata);
  $values =~ s#^.+:##;
  $values =~ s#^\s+##;
  $values =~ s#\s+$##;
  my %main_data;
  @main_data{split(/\s+/, $names)} = split(/\s+/, $values);
  return \%main_data;
}

sub update_rrd_data($@) {
  my $rrd = shift;
  my @values = @_;
  `rrdtool update $rrd N:@{[join(':', @values)]}`;
}

sub init($) {            
  my $email = shift;
  my $pid = (grep(m#^\s*(?!$$ )(\d+) /usr/bin/perl .+/mon.pl#, `ps xwwo pid,command`))[0];  
  if ($main_conf{'stop'}) {
    if ($pid) {
      $pid =~ s#^\s+##;
      kill(15, (split(m#\s+#, $pid))[0]);
      print STDERR "pid @{[(split(m#\s+#, $pid))[0]]} terminated...\n";
      $pid = 0;
    }
    exit unless ($main_conf{'daemon'});
  }
  exit if ($pid);
  if ($main_conf{'daemon'}) {
    chdir "/tmp";
    my $child_pid = fork();
    if (!defined $child_pid) { 
      &mail($email, 'SysMon :: Start', 'Monitor is not started');
      die("Fork: $!\n");
    }
    $SIG{'CHLD'} = 'IGNORE';
    exit(0) if ($child_pid);
    close STDIN;
    close STDOUT;
    close STDERR;
    open STDIN, "/dev/null";
    open STDOUT, "/dev/null";
    open STDERR, "/dev/null";
    &mail($email, 'SysMon :: Start', "Monitor started successfully\n") unless ($main_conf{'stop'});
  }
}

sub mail($$$) {
  sub sendSMTP($) {
    my $buffer = shift;
    send(SMTP, $buffer, 0);
    recv(SMTP, $buffer, 200, 0);
    $buffer = (split(/\s+/, $buffer))[0];
    return 0 if ($buffer =~ /^(4|5)/);
    return 1;
  }
  my ($email, $subject, $body) = @_;
  my ($check, $code);
  my @date = gmtime;
  $date[5] += 1900;
  $date[4]++;
  if (!$main_conf{'daemon'}) {
    print STDERR "$subject\n$body$date[5]-$date[4]-$date[3]+$date[2]:$date[1]:$date[0]\n";
  } else {
    foreach (@mailservers) {
      my ($mailhost, $proto, $port, $myhostname) = ($_, 6, 25, `hostname`);  # mailserver, tcp, smtp, my hostname
      chomp($myhostname);
      my $iaddr = inet_aton($mailhost) || next;  # could not resolve $mailhost
      my $paddr = sockaddr_in($port, $iaddr);
      socket(SMTP, AF_INET(), SOCK_STREAM(), $proto) || next; # could not connect to $mailhost
      connect(SMTP, $paddr) || next; # could not connect to $mailhost
      select(SMTP);
      $| = 1;
      select(STDOUT);
      my $inpBuf;
      recv(SMTP, $inpBuf, 200, 0);
      next if (!$inpBuf);
      next if (!sendSMTP("HELO notify.king-support.com\n"));
      next if (!sendSMTP("MAIL FROM: <root\@$myhostname>\n"));
      foreach (split /,/, $email) {
        next if (!length($_));
        $code = 1 if (sendSMTP("RCPT TO: <$_>\n"));
      }
      next if (!$code);
      next if (!sendSMTP("DATA\n"));
      send(SMTP, "From: <root\@$myhostname>\n", 0);
      foreach (split /,/, $email) {
        next if (!length($_));
        send(SMTP, "To: <$_>\n", 0);
      }
      send(SMTP, "Subject: $subject\n\n", 0);
      send(SMTP, "$body", 0);
      send(SMTP, "$date[5]-$date[4]-$date[3]+$date[2]:$date[1]:$date[0]\n", 0);
      next if (!sendSMTP("\r\n.\r\n"));
      next if (!sendSMTP("QUIT\n"));
      close(SMTP);
      $check = 1;
      last;
    }
    if (!$check) {
      foreach (split /,/, $email) {
        next if (!length($_));
        open MAIL, "|$main_conf{'mail'} -s '$subject' $_";
        print MAIL "$body$date[5]-$date[4]-$date[3]+$date[2]:$date[1]:$date[0]\n";
        close MAIL;
      }
    }
  }
  openlog 'sysmon', 'cons, pid', 'user';
  setlogsock "unix";
  syslog 'err', "$subject - $body";
  closelog();
}

sub restart($$) {
  my ($main_prog, $file, $first_file_mtime) = @_;
  my $file_mtime = (stat $file)[9];
  if ($file_mtime != $first_file_mtime) {
    openlog 'sysmon', 'cons, pid', 'user';
    syslog 'err', "Mtime of $file was changed. Reloading...";
    closelog();
    if (!exec("$main_prog -stop -daemon")) {
      openlog 'sysmon', 'cons, pid', 'user';
      syslog 'err', "%m";
      closelog();
      die;
    }
  }
}

sub restart_dyn_apaches() {
  my $status;
  foreach (keys(%dyn_apache_conf)) {
    my ($user, $process) = split(/\|/, $_, 2);
    my ($stop, $start) = split(/\|/, $dyn_apache_conf{$_}, 2);
    `$stop`;
    sleep(3);
    my $pid = (split(/\s+/, `ps -axwww -U '$user' | grep '$process' | grep -v grep`))[0];
    if (!$pid) {
      `$start`;
      if (!$?) {
        $status .= "$process: restarted;" 
      } else {
        $status .= "$process: could not restarted;";
      }
    } else {
      if (!kill(9, $pid)) {
        $status .= "$process: could not restarted;";
      } else {
        `$start`;
        if ($? == 0) {
          $status .= "$process: restarted;" 
        } else {
          $status .= "$process: could not restarted;";
        }
      }
    }
  }
  $status =~ s/\;$//;
  return $status; 
}

sub mon_net_if($$) {
  return unless ($main_conf{'mon_net_if'});
  my ($email, $mon_cycles) = @_;
  $mon_cycles *= 60;
  my $body = '';
  return unless ($main_conf{'mon_net_if_period'});
  return unless ($mon_cycles % $main_conf{'mon_net_if_period'} >= 0 && $mon_cycles % $main_conf{'mon_net_if_period'} < 1);
  foreach my $if (grep(m#^\d+:\s+\w+:\s+<.*>#, `ip link show up`)) {
    $if = $1 if ($if =~ m#^\d+:\s+(\w+):\s+<.*>#);
    my $speed = `ethtool $if |grep -i 'speed'| awk '{print \$2}'`;
    my $duplex = `ethtool $if |grep -i 'duplex'| awk '{print \$2}'`;
    if ($duplex eq 'Half') {
        `ethtool -s $if duplex full`;
        if ($?) {
            $body .= "Network interface $if is in ${speed}-HalfDuplex now. Could not change\n";
        } else {
            $body .= "Network interface $if was in ${speed}-HalfDuplex. Successfully changed\n";
        }
     }
  }
  &mail($email, 'SysMon :: Network Interface', $body) if (length($body));
}

sub mon_disk_usage($) {
  return unless ($main_conf{'mon_disk_usage'});
  my $email = shift;
  my $body = '';
  my @d_u_current = `df -k -t ext2 -t ext3 -t ext4 -t reiserfs -t xfs -P`;
  shift(@d_u_current);
  foreach (@d_u_current) {
    chomp;
    my ($size, $avail, $capacity, $mount_point) = (split(/\s+/, $_, 6))[1, 3, 4, 5];
    next if ($mount_point eq '/.mysqlbackup');
    $capacity =~ s/\%$//;
    next if (grep(/^$mount_point$/, @not_mon_fs_conf));
    if ($avail / 1024 < $main_conf{'disk_space_mon_min_rest'}) {
      if ($avail / 1024 <= $main_conf{'disk_space_min_rest'}) {
        $body .= "$mount_point(free $avail, usage $capacity%)\n";
      } else {
        if (&check_limit_usage($capacity, "du_$mount_point", $main_conf{'disk_space_max_usage'}, 
          $main_conf{'disk_space_usage_increment'})) 
        {
          $body .= "$mount_point(free $avail, usage $capacity%)\n";
        }
      }
    }
  }
  my @i_u_current = `df -ik -t ext2 -t ext3 -t ext4 -t reiserfs -t xfs -P`;
  shift(@i_u_current);
  foreach (@i_u_current) {
    chomp;
    my ($capacity, $mount_point) = (split(/\s+/, $_, 6))[4, 5];
    next if ($mount_point eq '/.mysqlbackup');
    $capacity =~ s/\%$//;
    next if (grep(/^$mount_point$/, @not_mon_fs_conf));
    if (&check_limit_usage($capacity, "inodes_$mount_point", $main_conf{'disk_inodes_max_usage'}, 
      $main_conf{'disk_inodes_usage_increment'})) 
    {
      $body .= "$mount_point(inodes usage $capacity%)\n";
    }
  }
  &mail($email, 'SysMon :: Disk OverUsage', $body) if (length($body));
}

sub mon_sysctl_usage($) {
  return unless ($main_conf{'mon_sysctl_usage'});
  my $email = shift;
  my $sysctl_usage;
  my $body = '';
  my %c_sysctl_conf;
  foreach (keys(%sysctl_conf)) {
    my $key = $_;
    $key =~ s#^.+\|##;
    $c_sysctl_conf{$key} = $sysctl_conf{$_};
  }
  my ($string1, $string2) = (join(' ', keys(%c_sysctl_conf)), join(' ', values(%c_sysctl_conf)));
  my (%sysctl_current, %sysctl_max);
  @sysctl_current{keys(%c_sysctl_conf)} = split(/\n/, `sysctl -n $string1 2>&1`);
  @sysctl_max{keys(%c_sysctl_conf)} = split(/\n/, `sysctl -n $string2 2>&1`);
  foreach(keys(%sysctl_conf)) {
    my ($usage_inc, $key);
    if ($_ =~ m#^.+\|#) {
      ($usage_inc, $key) = split(m#\|#, $_, 2);
    } else {
      $key = $_;
    }
    my $usage = defined($usage_inc) ? (split(m#:#, $usage_inc, 2))[0] : $main_conf{'sysctl_max_usage'};
    my $inc = defined($usage_inc) ? (split(m#:#, $usage_inc, 2))[1] : $main_conf{'sysctl_usage_increment'};
    my ($current, $max) = ($sysctl_current{$key}, $sysctl_max{$key}); 
    $current = (split(m#\s+#, $current))[0];
    $max = (split(m#\s+#, $max))[0];
    $sysctl_usage = ($current =~ /^error:/ 
      || $max =~ /^error:/ || $max == 0) ? 0 : $current / $max * 100;
    if (&check_limit_usage($sysctl_usage, "$key", $usage, $inc)) {
      $body .= "$key / $c_sysctl_conf{$key} = " . $sysctl_usage . "%\n";
    }
  }
  &mail($email, 'SysMon :: Sysctl OverUsage', $body) if (length($body));
}

sub mon_cpu_overload($$$) {
  my ($email, $mon_cycles, $rrd) = @_;
  my $body = '';
  return unless ($main_conf{'mon_cpu_overload'});
  $mon_cycles *= 60;
  return unless ($main_conf{'mon_cpu_overload_period'});
  return unless ($mon_cycles % $main_conf{'mon_cpu_overload_period'} >= 0 
    && $mon_cycles % $main_conf{'mon_cpu_overload_period'} < 1);
  # обработка load по rrd
  my $cpu_load = &get_rrd_data($rrd, 'AVERAGE', $main_conf{'mon_cpu_overload_period'});
  if ($cpu_load->{'cpu_idle'} <= $main_conf{'min_cpu_overload_idle'}) {
    $body = "CPU idle = ". sprintf("%.2f", $cpu_load->{'cpu_idle'}) . "%\n";
    $body .= "Top 10 CPU eaters:\n";
    $body .= `ps auxwwS| sort -rnk 3 | head -n 10`;
    $body .= "\n\n";
  }
  if ($cpu_load->{'cpu_sys'} + $cpu_load->{'cpu_hi'} + $cpu_load->{'cpu_si'} >= $main_conf{'max_cpu_overload_sys_interrupt'}) {
    $body .= "CPU System + CPU Interrupt = ${ \( sprintf(\"%.2f\", $cpu_load->{'cpu_sys'} + $cpu_load->{'cpu_hi'} + $cpu_load->{'cpu_si'}) ) } %\n";
  }
  if ($cpu_load->{'cpu_iowait'} >= $main_conf{'max_cpu_overload_iowait'}) {
    $body .= "CPU iowait = ". sprintf("%.2f", $cpu_load->{'cpu_iowait'}) . "%\n";
  }
  #
  &mail($email, "SysMon :: CPU OverLoad for last $main_conf{'mon_cpu_overload_period'} seconds", $body) if (length($body));
}

sub mon_swap_usage($$@) {
  my ($email, $top) = (shift, shift);
  my @ps = @_;
  return unless ($main_conf{'mon_swap_usage'});
  my ($mem_free, $swap_usage);
  my $body = '';
  $mem_free = $3 if ($top =~ /Mem:\s+(\d+.)\s+total,\s+(\d+.)\s+used,\s+(\d+.)\s+free,\s+(\d+.)\s+buffers/i);
  $swap_usage = $2 if ($top =~ /Swap:\s+(\d+.)\s+total,\s+(\d+.)\s+used,\s+(\d+.)\s+free,\s+(\d+.)\s+cached/i);
  $mem_free = defined($mem_free) ? &data_to_mb($mem_free) : 0;
  $swap_usage = defined($swap_usage) ? &data_to_mb($swap_usage) : 0;
  if ($swap_usage >= $main_conf{'swap_max_usage'} && $mem_free <= $main_conf{'memory_min_usage'}) {
    if (&check_limit_usage($swap_usage, "swap_usage", $main_conf{'swap_max_usage'}, $main_conf{'swap_usage_increment'})) {
      $body .= "\nTop 10 memory users:\n";
      $body .= `ps auxwwS| sort -rnk 4| head -n 10`;
      $body .= "\nMemory status:\n";
      $body .= `free`;
      $body .= "\n";
      if (!exists($main_conf{'first_swap_action'})) {
	$body .= &restart_dyn_apaches();
	$body .= "\n";
        $body .= "Apache restarted...\n";
        $main_conf{'first_swap_action'} = 1;
      } else {
        # 2. убить самый большой про сумме rss процесс
        my ($current_ps, $max_ps, $current_mem, $max_mem) = (0, 0, 0, 0);
        foreach $current_ps (keys(%mem_ps_conf)) {
          $current_mem += (split(/\s+/, $_, 8))[2] foreach(grep($current_ps, @ps));
          if ($current_mem >= $max_mem) {
            $max_ps = $current_ps;
            $max_mem = $current_mem;
          }
        }
        my ($how, $action) = (split(/\:/, $mem_ps_conf{"$max_ps"}, 2))[0, 1];
        if ($how == 1) {
          $body .= "Restart $max_ps: " .`$action`;
	  $body .= "\n";
        } elsif ($how == 2) {
          $body .= "Restart $max_ps: " . eval $action;
	  $body .= "\n";
        } else {
          $body .= "Unknown action for $max_ps restart. Check it.\n";
        }
        delete($main_conf{'first_swap_action'});
      }
    }
  } else {
    if (exists($prev_values{'swap_usage'})) {
      delete($main_conf{'first_swap_action'});
      delete($prev_values{'swap_usage'});
    }
  }
  &mail($email, 'SysMon :: Swap OverUsage', $body) if (length($body));
}

sub mon_la($$) {
  my ($email, $top) = @_;
  return unless ($main_conf{'mon_la'});
  my $la = $1 if ($top =~ /load\saverage\:\s+(\d+\.\d+)\,\s+(\d+\.\d+)\,\s+(\d+\.\d+)/i);
  my $body = '';
  if (&check_limit_usage($la, "la", $main_conf{'la_max'}, $main_conf{'la_increment'})) {
    $body = "Current LA = $la\n";
    $body .= "Top 10 CPU eaters:\n";
    $body .= `ps auxwwS| sort -rnk 3 | head -n 10`;
    $body .= "\n\n";
  }
  &mail($email, 'SysMon :: Load Averages', $body) if (length($body));
}

sub mon_zombie_count($@) {
  my $email = shift;
  my @ps = @_;
  return unless ($main_conf{'mon_zombie_count'});
  my $body = '';
  my $zc = scalar(grep(/\s+Z\s+/, @ps));
  if (&check_limit_usage($zc, "zc", $main_conf{'zc_max'}, $main_conf{'zc_increment'})) {
    $body = "Current zombie processes count = $zc. Restarting apaches.\n";
    $body .= &restart_dyn_apaches();
    $body .= "\n";
  }
  &mail($email, 'SysMon :: Zombie Processes Count', $body) if (length($body));
}

sub mon_apache_max_clients($%) {
  my $email = shift;
  my %monthes = @_;
  return unless ($main_conf{'mon_apache_maxclients'});
  my $body = '';
  foreach (keys(%apache_logs_conf)) {
    my $log = $apache_logs_conf{$_};
    my $error_message = `tail -200 $log | grep -i 'server reached MaxClients setting' | tail -1`;
    next if (!length($error_message));
    chomp($error_message);
    my ($month, $day, $time, $year) = (split /\s+/, $error_message)[1, 2, 3, 4];
    $day = "0$day" if (length($day) == 1);
    $year =~ s/\]$//;
    my ($hour, $min, $sec) = split(/:/, $time, 3);
    my $unix_time = `date -d "$month ${day} $time $year" "+%s"`;
    chomp($unix_time);
    if (!exists($prev_values{"$log"}) || (exists($prev_values{"$log"}) && $prev_values{"$log"} < $unix_time)) {
      $body .= "[$day:$monthes{$month}:$year:$hour-$min-$sec] ErrorLog - $log\n";
      $prev_values{"$log"} = $unix_time;
    }
  }
  if (length($body)) {
      $body .= "Restarted apache after reaching MaxClients! Please increase if it's not old message\n";
      $body .= &restart_dyn_apaches();
      $body .= "\n";
  }
  &mail($email, 'SysMon :: Apache MaxClients Setting OverReached', $body) if (length($body));
}

sub mon_mysql($$@) {
  my ($email, $top) = (shift, shift);
  my @ps = @_;
  return unless ($main_conf{'mon_mysql'});
  my $body = '';
  $ENV{'HOME'} = '/root';
  foreach(keys(%mysql_ps_conf)) {
    my ($mysql_data, $mysql_restart_action) = ($_, $mysql_ps_conf{$_});
    my ($mysql_ps, $mysql_socket) = split(/\|/, $mysql_data, 2);
    my ($mysql_cpu_usage, $mysql_pid) = (0, 0);
    if (grep(m#$mysql_ps($|\s)#, @ps)) {
      ($mysql_cpu_usage, $mysql_pid) = (split m#\s+#, (grep(m#$mysql_ps($|\s)#, @ps))[0])[3, 1];
      $mysql_cpu_usage =~ tr/,0-9/.0-9/;
    }
    my $mysql_check_result = `mysqladmin --socket=$mysql_socket --connect-timeout=5 ping 2>&1`;
    if ($mysql_check_result =~ /Access\sdenied/i) {
      $body .= "Wrong password in /root/.my.cnf(for $mysql_ps). Access denied.\n";
      $main_conf{'mon_mysql'} = 0;
      next;
    } elsif ($mysql_check_result =~ /Can\'t\sconnect/) {
      $body .= "Can't connect to $mysql_ps. Restarting:\n" . `$mysql_restart_action` . "\n";
    } elsif ($mysql_check_result =~ /Lost\sconnection/) {
      $body = "$mysql_ps was dead. Restarting:\n" . `kill -9 $mysql_pid` . "\n";
    } elsif ($mysql_check_result eq "mysqld is alive\n") {
      if($mysql_cpu_usage > $main_conf{'ps_load_max'}) {
        if($top =~ / (\d+\.?\d*)%\sni.+ (\d+\.?\d*)%\sid/) {
          my $current_idle = $1 + $2;
          if($current_idle < $main_conf{'idle_min'}) {
            $body = "$mysql_ps is eating $mysql_cpu_usage% of CPU. Restarting:\n" . `$mysql_restart_action`. "\n";
          }
        }
      }
    } else  {
      $body = $mysql_check_result;
    }
  }
  &mail($email, 'SysMon :: MySQL Problem', $body) if (length($body));
}

sub mon_ps($@) {
  my $email = shift;
  my @ps = @_;
  return unless ($main_conf{'mon_run_ps'});
  my $body = '';
  foreach (keys(%run_ps_conf)) {
    my ($ps, $ps_start_action) = ($_, $run_ps_conf{$_});
    my $ps_user;
    ($ps_user, $ps) = split(m#\|#, $ps, 2);
    my $ps_count = scalar(grep(m#^($ps_user).*\s+($ps)($|\s)#, @ps));
    if ($ps_count == 0) {
      $body .= "$ps isn't running. Starting:\n" . `$ps_start_action` . "\n";
    }
  }
  if (length($body)) {
    &mail($email, 'SysMon :: Running Processes', $body);
    undef($body);
  }
  return unless ($main_conf{'mon_load_ps'});
  my @ps_current;
  foreach (@ps) {
    @ps_current = (split(/\s+/, $_, 8))[0, 1, 3, 5, 6, 7];
    next if ($ps_current[5] =~ /\[idle\]/);
    my $ps_etime = $ps_current[3];
    $ps_etime =~ /(\d+):(\d+)$/;
    $ps_etime = $1 * 60 + $2;
    $ps_etime = $1 * 3600 if ($ps_etime =~ /(\d+):\d+:\d+$/);
    $ps_etime = $1 * 3600 * 24 if ($ps_etime =~ /(\d+)\-/);
    my $ps_cputime = $ps_current[4];
    $ps_cputime =~ /(\d+):(\d+)[,.]/;
    $ps_cputime = $1 * 60 + $2;
    next if (($ps_cputime < $main_conf{'cputime_max'}) || $ps_etime == 0 || $ps_current[0] eq 'root' 
      || $ps_current[0] eq 'mailnull' || $ps_current[0] eq 'pgsql' || $ps_current[0] eq 'mysql');
    $ps_current[2] =~ s/\,/\./;
    if ($ps_current[2] >= $main_conf{'ps_load_max'} && ($ps_cputime * $main_conf{'cpu_mul_renice'}) > $ps_etime 
      && $ps_current[5] =~ /gzip|tar|sshd($|\s)/ && !exists($load_ps{$ps_current[1]}) && $ps_current[0] !~ /postfix/) 
    {
      $body .= "$ps_current[5](pid $ps_current[1], cpu $ps_current[2]%, uid $ps_current[0] reniced:\n";
      $body .=  `renice '+$main_conf{'renice_value'}' '$ps_current[1]'` . "\n";
      $load_ps{$ps_current[1]} = 'r';
    } elsif ($ps_current[2] >= $main_conf{'ps_load_max'} && ($ps_cputime * $main_conf{'cpu_mul_renice'}) > $ps_etime 
      && $ps_current[5] !~ /gzip|tar|sshd($|\s)/ && !exists($load_ps{$ps_current[1]}) && $ps_current[0] !~ /postfix/) 
    {
      $body .= "$ps_current[5](pid $ps_current[1], cpu $ps_current[2]%, uid $ps_current[0] reniced:\n";
      $body .=  `renice '+$main_conf{'renice_value'}' '$ps_current[1]'` . "\n";
      $load_ps{$ps_current[1]} = 'r';
    } elsif ($ps_current[2] >= $main_conf{'ps_load_max'} && ($ps_cputime * $main_conf{'cpu_mul_restart'}) > $ps_etime 
      && $ps_current[5] !~ /(gzip|tar|sshd)($|\s)/ && $ps_current[0] !~ /postfix|mysql/ && exists($load_ps{$ps_current[1]})) 
    {
      my $signal;
      if ($load_ps{$ps_current[1]} eq 'r') {
        $signal = 15;
        $load_ps{$ps_current[1]} = '15';
      } elsif ($load_ps{$ps_current[1]} eq '15') {
        $signal = 9;
        $load_ps{$ps_current[1]} = '9';
      } elsif ($load_ps{$ps_current[1]} eq '9') {
        $body .= "$ps_current[5](pid $ps_current[1], cpu $ps_current[2]%, uid $ps_current[0] couldn't be killed\n";
      }
      if (defined($signal)) {
        $body .= "$ps_current[5](pid $ps_current[1], cpu $ps_current[2]%, uid $ps_current[0] on signal $signal killed: ";
        $body .= $! . "\n" if (!kill($signal, $ps_current[1]));
      }
    } elsif ($ps_current[2] < $main_conf{'ps_load_max'} && exists($load_ps{$ps_current[1]})) {
      delete($load_ps{$ps_current[1]});
    }
  }
  foreach (each(%load_ps)) {
    delete($load_ps{$ps_current[1]}) if (!grep(/^(\w+)\s+$ps_current[1]\s+/, @ps)); 
  }
  if (length($body)) {
    &mail($email, 'SysMon :: Process CPU OverLoad', $body);
    undef($body);
  }
  return unless ($main_conf{'mon_ps_count'});
  my $ps_count = $#ps + 1;
  if ($ps_count >= $main_conf{'pc_max'}) {
    $body = "Current processes count = $ps_count. Restarting apaches.\n";
    $body .= &restart_dyn_apaches();
    $body .= "\n";
  }
  &mail($email, 'SysMon :: Processes Count', $body) if (length($body));
}

# statistics functions
sub get_net_if_traffic($) {
  my $net_if = shift;
  my %main_data;
  my $data = (grep(m#^\s*$net_if:\s*#, `cat /proc/net/dev`))[0];
  $data =~ s/^\s*//;
  ($main_data{"traf_in"}, $main_data{"traf_out"}) = (split(m#\s+#, $data, 17))[1, 9];
  return \%main_data;
}

sub get_cpu_usage($) {
  my $top = shift;
  my %main_data;
  if ($top =~ m#Cpu.+:\s*(\d+\,?\d*)\s+us,\s*(\d+\,?\d*)\s+sy,\s*(\d+\,?\d*)\s+ni,\s*(\d+\,?\d*)\s+id,\s*(\d+\,?\d*)\s+wa,\s*(\d+\,?\d*)\s+hi,\s*(\d+\,?\d*)\s+si,\s*(\d+\,?\d*)\s+st#i || $top =~ m#Cpu.+:\s*(\d+\.?\d*)\s+us,\s*(\d+\.?\d*)\s+sy,\s*(\d+\.?\d*)\s+ni,\s*(\d+\.?\d*)\s+id,\s*(\d+\.?\d*)\s+wa,\s*(\d+\.?\d*)\s+hi,\s*(\d+\.?\d*)\s+si,\s*(\d+\.?\d*)\s+st#i) {
    $main_data{'cpu_user'} = $1;
    $main_data{'cpu_sys'} = $2;
    $main_data{'cpu_nice'} = $3;
    $main_data{'cpu_idle'} = $4;
    $main_data{'cpu_iowait'} = $5;
    $main_data{'cpu_hi'} = $6;
    $main_data{'cpu_si'} = $7;
    $main_data{'cpu_st'} = $8;
    $main_data{'cpu_user'} =~ tr/,0-9/.0-9/;
    $main_data{'cpu_sys'} =~ tr/,0-9/.0-9/;
    $main_data{'cpu_nice'} =~ tr/,0-9/.0-9/;
    $main_data{'cpu_idle'} =~ tr/,0-9/.0-9/;
    $main_data{'cpu_iowait'} =~ tr/,0-9/.0-9/;
    $main_data{'cpu_hi'} =~ tr/,0-9/.0-9/;
    $main_data{'cpu_si'} =~ tr/,0-9/.0-9/;
    $main_data{'cpu_st'} =~ tr/,0-9/.0-9/;
  }
  return \%main_data;
}

sub get_la($) {
  my $top = shift;
  my %main_data;
  if ($top =~ /load\saverage\:\s+(\d+\,\d+)\,\s+(\d+\,\d+)\,\s+(\d+\,\d+)/ || $top =~ /load\saverage\:\s+(\d+\.\d+)\,\s+(\d+\.\d+)\,\s+(\d+\.\d+)/) {
    $main_data{'la_1'} = $1;
    $main_data{'la_5'} = $2;
    $main_data{'la_15'} = $3;
    $main_data{'la_1'} =~ tr/,0-9/.0-9/;
    $main_data{'la_5'} =~ tr/,0-9/.0-9/;
    $main_data{'la_15'} =~ tr/,0-9/.0-9/;
  }
  return \%main_data;
}

sub get_ps_count(@) {
  my @ps = @_;
  my (%main_data, $pc_sum);
  foreach (@count_ps_conf) {
    my $regexp = $_ . '(\s|$)';
    $main_data{"pc_$_"} = scalar(grep(m#$regexp#, @ps));
    $pc_sum += $main_data{"pc_$_"}
  }
  $main_data{'pc_zombie'} = scalar(grep(/\s+Z\s+/, @ps));
  $main_data{'pc_other'} = $#ps + 1 - $pc_sum;
  return \%main_data;
}

sub get_mysql_stats() {
  my %main_data;
  return undef if (!$main_conf{'mon_mysql'});
  my $mysql_stats = `mysqladmin --connect-timeout=5 status`;
  chomp($mysql_stats);
  $main_data{'mysql_questions'} = $1 if ($mysql_stats =~ /Questions\:\s(\d+)?/);
  $main_data{'mysql_threads'} = $1 if ($mysql_stats =~ /Threads\:\s(\d+)/);
  $main_data{'mysql_slow_queries'} = $1 if ($mysql_stats =~ /Slow\squeries\:\s(\d+)/);
  return \%main_data;
}

sub get_disk_usage() {
  my %main_data;
  my @d_u_current = `df -k -t ext2 -t ext3 -t ext4 -t reiserfs -t xfs -P`;
  shift(@d_u_current);
  foreach (@d_u_current) {
    chomp;
    my ($space, $mount_point) = (split(/\s+/, $_, 6))[4, 5];
    next if ($mount_point eq '/.mysqlbackup');
    $space =~ s/\%$//;
    $main_data{"space_$mount_point"} = $space;
  }
  my @i_u_current = `df -ik -t ext2 -t ext3 -t ext4 -t reiserfs -t xfs -P`;
  shift(@i_u_current);
  foreach (@i_u_current) {
    chomp;
    my ($inodes, $mount_point) = (split(/\s+/, $_, 6))[4, 5];
    next if ($mount_point eq '/.mysqlbackup');
    $inodes =~ s/\%$//;
    $main_data{"inodes_$mount_point"} = $inodes;
  }
  return \%main_data;
}

sub get_mem_usage($) {
  my $top = shift;
  my %main_data;
  my ($mem_total, $mem_free, $mem_used, $mem_buffers) = ($1, $2, $3, $4) 
	if ($top =~ /Mem\s+:\s+(\d+.)\s+total,\s+(\d+.)\s+free,\s+(\d+.)\s+used,\s+(\d+.)\s+buff/i);
  my $swap_usage = $2 if ($top =~ /Swap:\s+(\d+.)\s+total,\s+(\d+.)\s+free,\s+(\d+.)\s+used,\s+(\d+.)\s+avail/i);
  $main_data{'mem_total'} = defined($mem_total) ? &data_to_mb($mem_total) : 0;
  $main_data{'mem_used'} = defined($mem_used) ? &data_to_mb($mem_used) : 0;
  $main_data{'mem_free'} = defined($mem_free) ? &data_to_mb($mem_free) : 0;
  $main_data{'mem_buffers'} = defined($mem_buffers) ? &data_to_mb($mem_buffers) : 0;
  $main_data{'mem_swap'} = defined($swap_usage) ? &data_to_mb($swap_usage) : 0;
  return \%main_data;
}

sub get_ps_size(@) {
  my @ps = @_;
  my (%main_data, @mem);
  my @httpd = grep(/httpd(\s+|$)/, @ps);
  push(@mem, (split(/\s+/, $_, 8))[2]) foreach(@httpd);
  @mem = reverse sort {$a <=> $b} @mem;
  $mem[0] = defined($mem[0]) ? $mem[0] : 0; 
  $main_data{'max_httpd'} = int(1000 * $mem[0] / 1024) / 1000; # max httpd
  undef(@mem);
  my @mysqld = grep(/mysqld(\s+|$)/, @ps);
  push(@mem, (split(/\s+/, $_, 8))[2]) foreach(@mysqld);
  @mem = reverse sort {$a <=> $b} @mem;
  $mem[0] = defined($mem[0]) ? $mem[0] : 0; 
  $main_data{'max_mysqld'} = int(1000 * $mem[0] / 1024) / 1000; # max mysqld
  undef(@mem);
  @ps = grep(!/(mysqld|httpd)(\s+|$)/, @ps);
  push(@mem, (split(/\s+/, $_, 8))[2]) foreach(@ps);
  @mem = reverse sort {$a <=> $b} @mem;
  $main_data{'first_max_ps'} = int(1000 * $mem[0] / 1024) / 1000; # first ps
  $main_data{'second_max_ps'} = int(1000 * $mem[1] / 1024) / 1000; # second ps
  return \%main_data;
}

sub get_user_activity(@) {
  my @ps = @_;
  my (%main_data, %user_mem_usage, %user_cpu_usage, %user_pc);
  foreach (@ps) {
    next if ((split(/\s+/, $_))[7] =~ /\[idle\]/);
    my ($user, $mem_usage, $cpu_usage) = (split(/\s+/, $_))[0, 2 ,3];
    $cpu_usage =~ s/\,/\./;
    $user_mem_usage{$user} += int(1000 * $mem_usage / 1024) / 1000;
    $user_cpu_usage{$user} += $cpu_usage;
    $user_pc{$user}++ ;
  }
  my $count = scalar(keys(%user_cpu_usage)) <= 4 ? scalar(keys(%user_cpu_usage)) - 1 : 4;
  foreach my $user ((sort {$user_cpu_usage{$b} <=> $user_cpu_usage{$a}} keys(%user_cpu_usage))[0..$count]) {
    $main_data{$user} = "$user_cpu_usage{$user}:$user_mem_usage{$user}:$user_pc{$user}";
  }
  return \%main_data;
}

sub get_hdd_stats {
  my %main_data;
  my $disks = `fdisk -l 2>/dev/null | grep '^Disk /dev/[sh]d[a-z]' | awk '{print \$2}' | sed -e 's#:\$##' | xargs echo -n`;
  my @n = split(/\s+/, $disks);
  my $n = $#n + 1;
  my @data = split(/\n/, `iostat -d 5 2 -m -x -d $disks`);
  shift(@data);
  for (my $i = $#data; $i > $#data - $n; $i--) {
    my ($rs, $ws, $mrs, $mws) = (split(/\s+/, $data[$i], 12))[3, 4, 5, 6];
    $rs =~ tr/,0-9/.0-9/;
    $ws =~ tr/,0-9/.0-9/;
    $mrs =~ tr/,0-9/.0-9/;
    $mws =~ tr/,0-9/.0-9/;
    $main_data{'hdd_rs'} += $rs;
    $main_data{'hdd_mrs'} += $mrs * 8;
    $main_data{'hdd_ws'} += $ws;
    $main_data{'hdd_mws'} += $mws * 8;
  }
  return \%main_data;
}

sub get_sysctl_usage {
  my (%main_data, %c_sysctl_conf);
  foreach (keys(%sysctl_conf)) {
    my $key = $_;     
    $key =~ s#^.+\|##;
    $c_sysctl_conf{$key} = $sysctl_conf{$_};  
  }
  my ($string1, $string2) = (join(' ', keys(%c_sysctl_conf)), join(' ', values(%c_sysctl_conf)));
  my (%sysctl_current, %sysctl_max);
  @sysctl_current{keys(%c_sysctl_conf)} = split(/\n/, `sysctl -n $string1 2>&1`);
  @sysctl_max{keys(%c_sysctl_conf)} = split(/\n/, `sysctl -n $string2 2>&1`);
  foreach(keys(%c_sysctl_conf)) {
    my $key = $_;
    my ($current, $max) = ($sysctl_current{$key}, $sysctl_max{$key});
    $current = (split(m#\s+#, $current))[0];
    $max = (split(m#\s+#, $max))[0];
    $main_data{$key} = ($current =~ /^error:/ 
      || $max =~ /^error:/ || $max == 0) ? 0 : $current / $max * 100;
  }
  return \%main_data;
}

our $last_mon_apache_page = 'state not set yet';
sub mon_apache_page {
    return unless ($main_conf{'mon_apache_page'});
    my ($email, $mon_cycles) = @_;
    $mon_cycles *= 60;
    return unless ($main_conf{'mon_apache_page_period'});
    return unless ($mon_cycles % $main_conf{'mon_apache_page_period'} >= 0 && $mon_cycles % $main_conf{'mon_apache_page_period'} < 1);
    my $config = $main_conf{'apache_conf_path'};
    my $IP = substr(`cat $config/82port.conf | grep Listen | grep 82 | awk '{print \$2}'`, 0, -1);
    #my $IP = `ifconfig  | grep 'inet addr' | head -n 1 | awk -F ":" '{print $2}' | awk '{print \$1}'`;
    my $page = "http://$IP/xtestnew.cgi";
    my $body = '';
    my $good = 0;
    my $datum = `curl -sN --connect-timeout 30 -m 60 $page || echo "apache:0"`;
    if ($datum eq $last_mon_apache_page){
        return;
    }
    my @data = split(/:/, $datum);
    for(my $i=0; $i < scalar(@data); $i++) {
        next unless ($i % 2); # process only check results
        if ($data[$i] != 1) {
            $body .= $data[$i-1] . ':' . $data[$i] . "\n";
	    if (($data[$i] eq "apache") && ($main_conf{'mon_apache_enabled'} == 1)) {
		$body .= &restart_dyn_apaches();
		$body .= "\n";
		$body .= "Apache was stuck, restarted\n";
	    }
        }
        else {
            $good = 1 ;
        }
    }
    if (($good == 0) && ($main_conf{'mon_apache_page_nonempty'} == 1)) {
        $body .= "No good tests! Whole data: $datum";
    }
    if ($datum eq $last_mon_apache_page) {
	$body = '';
    }
    else {
        $last_mon_apache_page = $datum;
    }
    &mail($email, "SysMon :: Apache check failed", $body) if (length($body));
}

1;

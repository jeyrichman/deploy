#!/usr/bin/perl -w

# modules
use strict;
use FindBin qw($Bin);
use vars qw($stop $daemon $v);
use lib "$Bin/../lib/$^O";
use Module;

# environment variables
$ENV{'PATH'} = '/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin:/usr/X11R6/bin';
$ENV{'BLOCKSIZE'} = 'K';

my $os_type = $^O;
my $os_release = `sysctl -n kernel.osrelease 2>/dev/null` . `sysctl -n kern.osrelease 2>/dev/null`;
chomp($os_release = lc($os_release));
my $os_branch;
if ($os_type eq 'freebsd') {
  $os_release = (split(/\-/, $os_release))[0];
  $os_release = $1 if ($os_release =~ m#^(\d+\.\d+)#);
  $os_branch = $os_release;
  $os_branch =~ s#\..*$##;
} elsif ($os_type eq 'linux') {
  $os_branch = 'all';
} else {
  die "OS is not supported.";
}

# variables
my $VERSION='0.0.1';
my $host = '127.0.0.1';
my $base_dir = "$Bin/..";
my $rrd_path = "$base_dir/rrdtool/rrd/$host";
my $conf_file = "$base_dir/conf/mon.conf.$os_type";
my $add_conf_file = "$conf_file-$os_branch";

# procedures && functions

# load configs
die if (!load_conf($conf_file, 1));
load_conf($add_conf_file, 0);

# main part
if (!-d "$rrd_path") {
  if (!mkdir "$rrd_path") {
    die "mkdir $rrd_path: $!";
  }
}

my $net_speed = '100M';
my $maxo = 13107200;

if ($os_type eq 'freebsd') {
  # Network Interfaces - dynamic
  mkdir "$rrd_path/net_if";
  foreach my $if (split(/\s+/, `ifconfig -l -u`)) {
    $net_speed = `ifconfig $if|grep media|awk '{print \$4}'|tail -c +2|awk -F'b' '{print \$1 "M"}'`;
    if ($net_speed =~ /M/) {
        $maxo = (split(/M/,$net_speed))[0]*1024*1024/8;
    }
    elsif ($net_speed =~ /G/) {
        $maxo = (split(/G/,$net_speed))[0]*1024*1024*1024/8;
    }
    else {
        $maxo = 'U'; }

    `rrdtool create $rrd_path/net_if/$if.rrd --start N --step 60 \\
       DS:traf_in:DERIVE:120:0:$maxo \\
       DS:traf_out:DERIVE:120:0:$maxo \\
       RRA:AVERAGE:0.5:1:864 \\
       RRA:AVERAGE:0.5:5:864 \\
       RRA:AVERAGE:0.5:60:864 \\
       RRA:AVERAGE:0.5:720:864 \\
       RRA:AVERAGE:0.5:2880:864
    `;
  }

  # CPU Usage
  `rrdtool create $rrd_path/cpu_usage.rrd --start N --step 60 \\
    DS:cpu_idle:GAUGE:120:U:U \\
    DS:cpu_sys:GAUGE:120:U:U \\
    DS:cpu_user:GAUGE:120:U:U \\
    DS:cpu_nice:GAUGE:120:U:U \\
    DS:cpu_interrupt:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # Resource Usage Per User - dynamic
  # will be create automatically
  mkdir "$rrd_path/users";

  # Load Average
  `rrdtool create $rrd_path/la.rrd --start N --step 60  \\
    DS:la_1:GAUGE:120:U:U \\
    DS:la_5:GAUGE:120:U:U \\
    DS:la_15:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # Resources Usage
  mkdir "$rrd_path/res_usage";
  `rrdtool create $rrd_path/res_usage/kmem_usage.rrd --start N --step 60  \\
    DS:usage:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;
  `rrdtool create $rrd_path/res_usage/kmem_pv_entry.rrd --start N --step 60  \\
    DS:usage:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;
  `rrdtool create $rrd_path/res_usage/mbuf_clusters.rrd --start N --step 60  \\
    DS:usage:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;
  `rrdtool create $rrd_path/res_usage/disk_activity.rrd --start N --step 60  \\
    DS:usage:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;
  foreach (keys(%sysctl_conf)) {
    my $rrd = $_;
    $rrd =~ s#^.+\|##g;
    $rrd =~ s#\.#_#g;
    `rrdtool create $rrd_path/res_usage/$rrd.rrd --start N --step 60  \\
      DS:usage:GAUGE:120:U:U \\
      RRA:AVERAGE:0.5:1:864 \\
      RRA:AVERAGE:0.5:5:864 \\
      RRA:AVERAGE:0.5:60:864 \\
      RRA:AVERAGE:0.5:720:864 \\
      RRA:AVERAGE:0.5:2880:864
    `;
  }

  # MySQL Stats
  `rrdtool create $rrd_path/mysql.rrd --start N --step 60  \\
    DS:mysql_q_per_sec:DERIVE:120:U:U \\
    DS:mysql_threads:GAUGE:120:U:U \\
    DS:mysql_slow_q:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # Memory Usage
  `rrdtool create $rrd_path/mem_usage.rrd --start N --step 60  \\
    DS:mem_active:GAUGE:120:U:U \\
    DS:mem_inactive:GAUGE:120:U:U \\
    DS:mem_wired:GAUGE:120:U:U \\
    DS:mem_cache:GAUGE:120:U:U \\
    DS:mem_buf:GAUGE:120:U:U \\
    DS:mem_free:GAUGE:120:U:U \\
    DS:mem_swap:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # Process Count - dynamic
  mkdir "$rrd_path/ps_count";
  `rrdtool create $rrd_path/ps_count/other.rrd --start N --step 60  \\
    DS:count:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;
  `rrdtool create $rrd_path/ps_count/zombie.rrd --start N --step 60  \\
    DS:count:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;
  foreach (@count_ps_conf) {
    my @paths = split(m#/#, $_);
    my $rrd = $paths[$#paths];
    `rrdtool create $rrd_path/ps_count/$rrd.rrd --start N --step 60  \\
      DS:count:GAUGE:120:U:U \\
      RRA:AVERAGE:0.5:1:864 \\
      RRA:AVERAGE:0.5:5:864 \\
      RRA:AVERAGE:0.5:60:864 \\
      RRA:AVERAGE:0.5:720:864 \\
      RRA:AVERAGE:0.5:2880:864
    `;
  }

  # Process Size
  `rrdtool create $rrd_path/ps_size.rrd --start N --step 60  \\
    DS:max_httpd:GAUGE:120:U:U \\
    DS:max_mysqld:GAUGE:120:U:U \\
    DS:first_max_ps:GAUGE:120:U:U \\
    DS:second_max_ps:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # HDD Stats
  `rrdtool create $rrd_path/hdd_load.rrd --start N --step 60  \\
    DS:hdd_read_per_sec:GAUGE:120:U:U \\
    DS:hdd_m_read_per_sec:GAUGE:120:U:U \\
    DS:hdd_write_per_sec:GAUGE:120:U:U \\
    DS:hdd_m_write_per_sec:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # Disk Usage[space + inode] - dynamic
  mkdir "$rrd_path/disk_usage";
  my @d_u_current = `df -t ufs,zfs`;
  shift(@d_u_current);
  chomp(@d_u_current);
  foreach (@d_u_current) {
    my $mount_point = (split(/\s+/, $_, 6))[5];
    next if ($mount_point eq '/.mysqlbackup');
    $mount_point =~ s#/#_#g;
    my $rrd = $mount_point;
    `rrdtool create $rrd_path/disk_usage/$rrd.rrd --start N --step 60  \\
      DS:space:GAUGE:120:U:U \\
      DS:inodes:GAUGE:120:U:U \\
      RRA:AVERAGE:0.5:1:864 \\
      RRA:AVERAGE:0.5:5:864 \\
      RRA:AVERAGE:0.5:60:864 \\
      RRA:AVERAGE:0.5:720:864 \\
      RRA:AVERAGE:0.5:2880:864
    `;
  }

  # Temperature[mbmon + sysctl]
  `rrdtool create $rrd_path/temperature.rrd --start N --step 60  \\
    DS:box_temp:GAUGE:120:U:U \\
    DS:proc_temp:GAUGE:120:U:U \\
    DS:min_core_temp:GAUGE:120:U:U \\
    DS:max_core_temp:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;
} elsif ($os_type eq 'linux') {
  # Network Interfaces - dynamic
  mkdir "$rrd_path/net_if";
  foreach my $if (grep(m#^\d+:\s+\w+:\s+<.*>#, `ip link show up`)) {
    $if = $1 if ($if =~ m#^\d+:\s+(\w+):\s+<.*>#);
    $net_speed = `ethtool $if|grep Speed|awk '{print \$2}'|awk -F 'b' '{print \$1}'`;
    if ($net_speed =~ /M/) {
        $maxo = (split(/M/,$net_speed))[0]*1024*1024/8;
    }
    elsif ($net_speed =~ /G/) {
        $maxo = (split(/G/,$net_speed))[0]*1024*1024*1024/8;
    }
    else {
        $maxo = 'U'; }
    `rrdtool create $rrd_path/net_if/$if.rrd --start N --step 60 \\
       DS:traf_in:DERIVE:120:0:$maxo \\
       DS:traf_out:DERIVE:120:0:$maxo \\
       RRA:AVERAGE:0.5:1:864 \\
       RRA:AVERAGE:0.5:5:864 \\
       RRA:AVERAGE:0.5:60:864 \\
       RRA:AVERAGE:0.5:720:864 \\
       RRA:AVERAGE:0.5:2880:864
    `;
  }

  # CPU Usage
  `rrdtool create $rrd_path/cpu_usage.rrd --start N --step 60 \\
    DS:cpu_user:GAUGE:120:U:U \\
    DS:cpu_sys:GAUGE:120:U:U \\
    DS:cpu_nice:GAUGE:120:U:U \\
    DS:cpu_idle:GAUGE:120:U:U \\
    DS:cpu_iowait:GAUGE:120:U:U \\
    DS:cpu_hi:GAUGE:120:U:U \\
    DS:cpu_si:GAUGE:120:U:U \\
    DS:cpu_st:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # Resource Usage Per User - dynamic
  # will be create automatically
  mkdir "$rrd_path/users";

  # Load Average
  `rrdtool create $rrd_path/la.rrd --start N --step 60  \\
    DS:la_1:GAUGE:120:U:U \\
    DS:la_5:GAUGE:120:U:U \\
    DS:la_15:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # Resources Usage
  mkdir "$rrd_path/res_usage";
  no warnings;
  foreach (keys(%sysctl_conf)) {
    my $rrd = $_;
    $rrd =~ s#^.+\|##g;
    $rrd =~ s#\.#_#g;
    `rrdtool create $rrd_path/res_usage/$rrd.rrd --start N --step 60  \\
      DS:usage:GAUGE:120:U:U \\
      RRA:AVERAGE:0.5:1:864 \\
      RRA:AVERAGE:0.5:5:864 \\
      RRA:AVERAGE:0.5:60:864 \\
      RRA:AVERAGE:0.5:720:864 \\
      RRA:AVERAGE:0.5:2880:864
    `;
  }
#  use warnings;

  # MySQL Stats
  `rrdtool create $rrd_path/mysql.rrd --start N --step 60  \\
    DS:mysql_q_per_sec:DERIVE:120:U:U \\
    DS:mysql_threads:GAUGE:120:U:U \\
    DS:mysql_slow_q:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # Memory Usage
  `rrdtool create $rrd_path/mem_usage.rrd --start N --step 60  \\
    DS:mem_total:GAUGE:120:U:U \\
    DS:mem_used:GAUGE:120:U:U \\
    DS:mem_free:GAUGE:120:U:U \\
    DS:mem_buffers:GAUGE:120:U:U \\
    DS:mem_swap:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # Process Count - dynamic
  mkdir "$rrd_path/ps_count";
  `rrdtool create $rrd_path/ps_count/other.rrd --start N --step 60  \\
    DS:count:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;
  `rrdtool create $rrd_path/ps_count/zombie.rrd --start N --step 60  \\
    DS:count:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;
  no warnings;
  foreach (@count_ps_conf) {
    my @paths = split(m#/#, $_);
    my $rrd = $paths[$#paths];
    `rrdtool create $rrd_path/ps_count/$rrd.rrd --start N --step 60  \\
      DS:count:GAUGE:120:U:U \\
      RRA:AVERAGE:0.5:1:864 \\
      RRA:AVERAGE:0.5:5:864 \\
      RRA:AVERAGE:0.5:60:864 \\
      RRA:AVERAGE:0.5:720:864 \\
      RRA:AVERAGE:0.5:2880:864
    `;
  }
  use warnings;

  # Process Size
  `rrdtool create $rrd_path/ps_size.rrd --start N --step 60  \\
    DS:max_httpd:GAUGE:120:U:U \\
    DS:max_mysqld:GAUGE:120:U:U \\
    DS:first_max_ps:GAUGE:120:U:U \\
    DS:second_max_ps:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # HDD Stats
  `rrdtool create $rrd_path/hdd_load.rrd --start N --step 60  \\
    DS:hdd_read_per_sec:GAUGE:120:U:U \\
    DS:hdd_m_read_per_sec:GAUGE:120:U:U \\
    DS:hdd_write_per_sec:GAUGE:120:U:U \\
    DS:hdd_m_write_per_sec:GAUGE:120:U:U \\
    RRA:AVERAGE:0.5:1:864 \\
    RRA:AVERAGE:0.5:5:864 \\
    RRA:AVERAGE:0.5:60:864 \\
    RRA:AVERAGE:0.5:720:864 \\
    RRA:AVERAGE:0.5:2880:864
  `;

  # Disk Usage[space + inode] - dynamic
  mkdir "$rrd_path/disk_usage";
  my @d_u_current = `df -k -t ext2 -t ext3 -t ext4 -t reiserfs -t xfs`;
  shift(@d_u_current);
  chomp(@d_u_current);
  foreach (@d_u_current) {
    my $mount_point = (split(/\s+/, $_, 6))[5];
    next if ($mount_point eq '/.mysqlbackup');
    $mount_point =~ s#/#_#g;
    my $rrd = $mount_point;
    `rrdtool create $rrd_path/disk_usage/$rrd.rrd --start N --step 60  \\
      DS:space:GAUGE:120:U:U \\
      DS:inodes:GAUGE:120:U:U \\
      RRA:AVERAGE:0.5:1:864 \\
      RRA:AVERAGE:0.5:5:864 \\
      RRA:AVERAGE:0.5:60:864 \\
      RRA:AVERAGE:0.5:720:864 \\
      RRA:AVERAGE:0.5:2880:864
    `;
  }
}
# end of main part

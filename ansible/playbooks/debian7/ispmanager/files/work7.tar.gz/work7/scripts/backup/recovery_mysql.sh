#!/bin/sh

gunzip */*gz
for dname in `ls -1 | grep -v recovery_mysql.sh`; do
	echo "create database $dname" | mysql	
	for tname in `ls -1 $dname/`; do
		mysql $dname < $dname/$tname 
	done
done
echo "flush PRIVILEGES" | mysql	

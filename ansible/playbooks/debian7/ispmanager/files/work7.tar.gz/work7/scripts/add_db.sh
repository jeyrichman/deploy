#!/bin/sh
DB_PASS=`perl -e 'for(0..14){$$p.=(0..9,"A".."Z","a".."z")[rand 62];}print "$$p\n";'`
DB_NAME=$1

if [[ ${#1} -ge 17 ]] ; then echo "Name too long (${#1} > 16)"; exit 1 ; fi
echo "create database ${DB_NAME}" | mysql
echo "GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_NAME}'@'localhost' IDENTIFIED BY '${DB_PASS}'" | mysql
echo "flush PRIVILEGES" | mysql

echo "${DB_NAME} / ${DB_NAME} / ${DB_PASS}"

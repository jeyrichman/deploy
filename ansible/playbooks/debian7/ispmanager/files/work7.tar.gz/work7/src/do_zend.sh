#!/bin/sh

mkdir -p /usr/local/lib/php/

#ioncube
cd /usr/work/src/
wget http://data.king-support.com/distfiles/Latest/ioncube-`uname -s`-`uname -m`.tar.gz -O /usr/work/src/ioncube.tar.gz
tar zxfp ioncube.tar.gz
cd ioncube*
cp ioncube_loader_lin_5.6_ts.so /usr/local/lib/php/
echo '[Zend]' >> /usr/local/lib/php.ini
echo 'zend_extension=/usr/local/lib/php/ioncube_loader_lin_5.6_ts.so' >> /usr/local/lib/php.ini
#zend
#cd /usr/work/src/
#wget http://data.king-support.com/distfiles/Latest/zend-`uname -s`-`uname -m`.tar.gz -O /usr/work/src/zend.tar.gz
#tar zxfp zend.tar.gz
#cd Zend*
#cp data/5_2_x_comp/ZendOptimizer.so /usr/local/lib/php/
#echo 'zend_extension=/usr/local/lib/php/ZendOptimizer.so' >> /usr/local/lib/php.ini

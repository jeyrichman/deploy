#!/bin/sh

cd /usr/work/src/apache2
make clean

export CC="gcc"
export CFLAGS="-O2 -pipe -funroll-loops"
export INCLUDES="-I/usr/local/include -I/usr/include"
export LDFLAGS="-L/usr/lib -L/usr/local/lib"


./configure \
--prefix=/usr/local/apache2 \
--enable-modules="access include log-config env setenvif  cgi cgid actions alias rewrite  headers dir unixd userdir " \
--with-pcre \
--enable-so \
--enable-http \
--enable-access-compat \
--disable-proxy-connect \
--disable-proxy-ftp \
--disable-proxy-ajp \
--disable-proxy-balancer \
--disable-asis \
--disable-imap \
--disable-userdir \
--enable-autoindex \
--disable-filter \
--disable-cgid \
--enable-authn-file \
--disable-authn-default \
--enable-auth-basic \
--disable-status \
--disable-threads \
--enable-suexec \
--with-suexec-userdir \
--with-suexec-bin=/usr/local/apache2/bin/suexec \
--with-suexec-caller=www \
--with-suexec-docroot=/home \
--with-suexec-logfile=/home/logs/suexec2_log \
--with-suexec-uidmin=1000 \
--with-suexec-gidmin=1000

make -s && make -s install && cd ../mod_geo*/ && /usr/local/apache2/bin/apxs -i -a -L/usr/local/lib -I/usr/local/include -lGeoIP -c mod_geoip.c

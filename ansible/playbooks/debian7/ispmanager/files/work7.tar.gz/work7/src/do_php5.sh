#!/bin/sh

cd /usr/work/src/php5
make clean
export CC=gcc
export CFLAGS="-O2 -pipe -funroll-loops"
./configure --with-apxs2=/usr/local/apache2/bin/apxs \
 --with-mysql \
 --without-pear \
 --enable-sockets \
 --enable-xml \
 --with-xmlrpc \
 --enable-dom \
 --enable-json \
 --enable-mbstring \
 --disable-debug \
 --enable-session \
 --enable-pdo \
 --with-pdo-mysql \
 --disable-hash \
 --disable-filter \
 --with-zlib \
 --with-gd \
 --with-curl \
 --enable-inline-optimization \
 --with-gnu-ld \
 --disable-exif \
 --enable-static \
 --disable-posix \
 --enable-ftp \
 --with-jpeg-dir \
 --with-libdir=/lib64 \
# --with-ttf \
# --with-freetype-dir=/usr/lib

make -s && make -s install
